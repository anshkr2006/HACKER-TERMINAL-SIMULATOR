const http = require("http");
const fs = require("fs");
const path = require("path");

const port = 3000;
const host = "127.0.0.1";
const contentTypes = {
  ".html": "text/html",
  ".css": "text/css",
  ".js": "text/javascript",
  ".md": "text/plain"
};

const server = http.createServer((request, response) => {
  const requestedPath = request.url === "/" ? "index.html" : request.url.slice(1);
  const filePath = path.join(__dirname, requestedPath);

  if (!filePath.startsWith(__dirname)) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      response.writeHead(404);
      response.end("Not found");
      return;
    }

    response.writeHead(200, {
      "Content-Type": contentTypes[path.extname(filePath)] || "text/plain"
    });
    response.end(data);
  });
});

server.listen(port, host, () => {
  console.log(`Hacker Terminal Simulator running on http://localhost:${port}`);
});
