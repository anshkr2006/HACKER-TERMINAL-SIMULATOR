const authScreen = document.getElementById("auth-screen");
const lobbyScreen = document.getElementById("lobby-screen");
const gameScreen = document.getElementById("game-screen");
const loginTab = document.getElementById("login-tab");
const signupTab = document.getElementById("signup-tab");
const authForm = document.getElementById("auth-form");
const authSubmit = document.getElementById("auth-submit");
const authMessage = document.getElementById("auth-message");
const lobbyName = document.getElementById("lobby-name");
const lobbyRank = document.getElementById("lobby-rank");
const lobbyLevel = document.getElementById("lobby-level");
const lobbyStreak = document.getElementById("lobby-streak");
const lobbyCredits = document.getElementById("lobby-credits");
const lobbyContent = document.getElementById("lobby-content");
const logoutButton = document.getElementById("logout-button");
const terminalOutput = document.getElementById("terminal-output");
const interactiveZone = document.getElementById("interactive-zone");
const stageTitle = document.getElementById("stage-title");
const hudName = document.getElementById("hud-name");
const hudId = document.getElementById("hud-id");
const hudMode = document.getElementById("hud-mode");
const hudLevel = document.getElementById("hud-level");
const hudStage = document.getElementById("hud-stage");
const hudTotal = document.getElementById("hud-total");
const hudScore = document.getElementById("hud-score");
const hudXp = document.getElementById("hud-xp");
const hudTime = document.getElementById("hud-time");
const hudCountdown = document.getElementById("hud-countdown");
const mainMenuButton = document.getElementById("main-menu-button");
const lineTemplate = document.getElementById("line-template");
const achievementStack = document.getElementById("achievement-stack");
const screenFlash = document.getElementById("screen-flash");
const matrixCanvas = document.getElementById("matrix-canvas");

let authMode = "login";
let timerId = null;
let countdownId = null;
let currentPanel = "how-to";
let runtimeTimeouts = new Set();
let runtimeIntervals = new Set();

const achievements = {
  firewall: { name: "Firewall Breaker", text: "Bypass a password firewall." },
  cipher: { name: "Cipher Master", text: "Decode a cipher challenge." },
  root: { name: "Root Access", text: "Execute the final root command." },
  silent: { name: "Silent Intruder", text: "Finish with two or fewer failed attempts." },
  elite: { name: "Elite Hacker", text: "Reach Elite rank or higher." },
  ghost: { name: "Ghost Hacker", text: "Win with no hints used." },
  streak: { name: "Streak Runner", text: "Maintain a multi-day hacking streak." },
  shopper: { name: "Black Market Buyer", text: "Purchase or upgrade a hacking tool." },
  legend: { name: "Darknet Legend", text: "Reach the highest competitive rank." }
};

const modeConfigs = {
  "Core Breach": {
    timeLimit: 720,
    loop: false,
    games: ["guess", "caesar", "vigenere", "ports", "prompt", "reverse", "memory", "binary", "morse", "logic", "pattern", "speed", "ascii", "hex", "base64", "debug", "password-profile", "ip"]
  },
  Rookie: {
    timeLimit: 300,
    loop: false,
    games: ["reverse", "speed", "memory"]
  },
  Intermediate: {
    timeLimit: 180,
    loop: false,
    games: ["pattern", "caesar", "guess", "logic"]
  },
  Hardcore: {
    timeLimit: 180,
    loop: false,
    games: ["binary", "morse", "vigenere"]
  },
  Speedrun: {
    timeLimit: 120,
    loop: false,
    games: ["memory", "speed", "guess", "reverse"]
  },
  Decrypt: {
    timeLimit: 480,
    loop: false,
    randomOrder: true,
    games: ["ascii", "hex", "base64", "binary", "morse"]
  },
  Debugger: {
    timeLimit: 180,
    loop: false,
    randomOrder: true,
    games: ["debug", "debug", "debug", "debug", "debug"]
  },
  "Password Profiling": {
    timeLimit: 300,
    loop: false,
    randomOrder: true,
    games: ["password-profile", "password-profile", "password-profile", "password-profile", "password-profile"]
  },
  Endless: {
    timeLimit: null,
    loop: true,
    games: ["guess", "caesar", "vigenere", "ports", "prompt", "reverse", "memory", "binary", "morse", "logic", "pattern", "speed", "ascii", "hex", "base64", "debug", "password-profile", "ip"]
  }
};

const modes = Object.keys(modeConfigs).reduce((items, name) => {
  items[name] = "";
  return items;
}, {});

const howToRuleCards = [
  {
    id: "ascii-conversion",
    title: "ASCII Conversion",
    rules: `A = 65
B = 66
C = 67
D = 68
E = 69
F = 70
G = 71
H = 72
I = 73
J = 74
K = 75
L = 76
M = 77
N = 78
O = 79
P = 80
Q = 81
R = 82
S = 83
T = 84
U = 85
V = 86
W = 87
X = 88
Y = 89
Z = 90`
  },
  {
    id: "hexadecimal-conversion",
    title: "Hexadecimal Conversion",
    rules: `A = 41
B = 42
C = 43
D = 44
E = 45
F = 46
G = 47
H = 48
I = 49
J = 4A
K = 4B
L = 4C
M = 4D
N = 4E
O = 4F
P = 50
Q = 51
R = 52
S = 53
T = 54
U = 55
V = 56
W = 57
X = 58
Y = 59
Z = 5A`
  },
  {
    id: "morse-code",
    title: "Morse Code",
    rules: `A  &middot;&minus;
B  &minus;&middot;&middot;&middot;
C  &minus;&middot;&minus;&middot;
D  &minus;&middot;&middot;
E  &middot;
F  &middot;&middot;&minus;&middot;
G  &minus;&minus;&middot;
H  &middot;&middot;&middot;&middot;
I  &middot;&middot;
J  &middot;&minus;&minus;&minus;
K  &minus;&middot;&minus;
L  &middot;&minus;&middot;&middot;
M  &minus;&minus;
N  &minus;&middot;
O  &minus;&minus;&minus;
P  &middot;&minus;&minus;&middot;
Q  &minus;&minus;&middot;&minus;
R  &middot;&minus;&middot;
S  &middot;&middot;&middot;
T  &minus;
U  &middot;&middot;&minus;
V  &middot;&middot;&middot;&minus;
W  &middot;&minus;&minus;
X  &minus;&middot;&middot;&minus;
Y  &minus;&middot;&minus;&minus;
Z  &minus;&minus;&middot;&middot;`
  },
  {
    id: "binary-conversion",
    title: "Binary Conversion",
    rules: `A = 01000001
B = 01000010
C = 01000011
D = 01000100
E = 01000101
F = 01000110
G = 01000111
H = 01001000
I = 01001001
J = 01001010
K = 01001011
L = 01001100
M = 01001101
N = 01001110
O = 01001111
P = 01010000
Q = 01010001
R = 01010010
S = 01010011
T = 01010100
U = 01010101
V = 01010110
W = 01010111
X = 01011000
Y = 01011001
Z = 01011010`
  },
  {
    id: "vigenere-cipher",
    title: "Vigenere Cipher",
    rules: `VIGENERE CIPHER DECRYPTION RULES

1. A=0, B=1, C=2 ... Z=25

2. Key:
KEY = 10,4,24
K=10
E=4
Y=24

3. Repeat the key according to the encrypted text length.

Example:
ENCRYPTED TEXT : RIJVS
KEY            : KEYKE

4. Decryption Formula:
P = (C - K + 26) mod 26

P = Plaintext value
C = Cipher value
K = Key value

5. Convert encrypted letters into numbers:

R = 17
I = 8
J = 9
V = 21
S = 18

KEY:
K = 10
E = 4
Y = 24
K = 10
E = 4

6. Calculations:

17-10=7 = H
8-4=4 = E
9-24+26=11 = L
21-10=11 = L
18-4=14 = O

7. Final Decrypted Text:
HELLO

8. Important Rules:
- Always use mod 26
- Add +26 if subtraction becomes negative
- Repeat the key when needed
- Convert final numbers back to letters`
  },
  {
    id: "misc",
    title: "Misc",
    rules: `==============================
GAME : GUESS THE NUMBER
==============================

RULES:
1. The system generates a random number.
2. The player must guess the correct number.
3. After every guess, a hint is shown:
   - Too High
   - Too Low
4. The player has limited attempts.
5. Correct guess wins the game.
6. Faster completion gives a better score.

==============================
GAME : CAESAR CIPHER
==============================

RULES:
1. Every letter is shifted by a fixed number.
2. A=0, B=1 ... Z=25
3. Encryption Formula:
   C = (P + K) mod 26
4. Decryption Formula:
   P = (C - K + 26) mod 26
5. Example:
   Shift = 3
   A -> D
   B -> E
6. The player must decrypt the encrypted text.

==============================
GAME : REVERSE CIPHER
==============================

RULES:
1. The text is reversed.
2. The player must restore the original text.
3. Example:
   HELLO -> OLLEH
4. Speed and accuracy both matter.

==============================
GAME : MEMORY HACK
==============================

RULES:
1. A text, code, or sequence is shown for a few seconds.
2. After the timer ends, the text disappears.
3. The player must type the exact same text from memory.
4. Mistakes reduce the score.
5. Longer sequences are harder levels.

==============================
GAME : LOGIC GATE
==============================

RULES:
1. The player must predict the output of logic gates.
2. Inputs are only 0 and 1.
3. Common gates:
   AND  -> 1 only if both inputs are 1
   OR   -> 1 if at least one input is 1
   XOR  -> 1 if inputs are different
   NAND -> opposite of AND
   NOR  -> opposite of OR
4. The player must enter the correct output.

==============================
GAME : PATTERN PREDICTION
==============================

RULES:
1. A sequence of numbers or letters is shown.
2. The player must find the hidden pattern.
3. The player predicts the next value.
4. Patterns may include:
   - Increasing numbers
   - Alternating letters
   - Mathematical sequences
5. Harder levels contain mixed patterns.

==============================
GAME : SPEED TYPING
==============================

RULES:
1. A text prompt is displayed.
2. The player must type the exact text.
3. A time limit is given.
4. Accuracy and speed both affect the score.
5. Wrong characters reduce accuracy.
6. Completing before time ends gives bonus points.`
  }
];

const tools = [
  { id: "decryptor", name: "Basic Decryptor", rarity: "Common", unlock: 0, unlockLevel: 1, cost: 0, desc: "Decodes beginner ciphers during training runs." },
  { id: "scanner", name: "Advanced Port Scanner", rarity: "Common", unlock: 0, unlockLevel: 1, cost: 0, desc: "Highlights safer network routes during scans." },
  { id: "bruteforce", name: "Brute Force Tool", rarity: "Common", unlock: 0, unlockLevel: 2, cost: 120, desc: "Speeds up simulated password cracking and adds firewall XP." },
  { id: "bypass", name: "Stealth Bypass", rarity: "Rare", unlock: 350, unlockLevel: 4, cost: 220, desc: "Injects a recovered firewall key when pressure gets high." },
  { id: "aiDecryptor", name: "AI Decryptor", rarity: "Rare", unlock: 450, unlockLevel: 6, cost: 260, desc: "Improves cipher help and grants bonus XP on decryptions." },
  { id: "analyzer", name: "Password Analyzer", rarity: "Rare", unlock: 520, unlockLevel: 8, cost: 300, desc: "Reveals stronger password patterns in firewall stages." },
  { id: "hintUnlocker", name: "Hint Unlocker", rarity: "Epic", unlock: 650, unlockLevel: 10, cost: 360, desc: "Adds bonus hints that do not reduce score." },
  { id: "stealth", name: "Stealth Cloak", rarity: "Epic", unlock: 750, unlockLevel: 12, cost: 440, desc: "Reduces penalties from mistakes and improves stealth endings." },
  { id: "shield", name: "Firewall Shield", rarity: "Epic", unlock: 820, unlockLevel: 14, cost: 480, desc: "Adds emergency protection during random security events." },
  { id: "xpMultiplier", name: "XP Multiplier", rarity: "Legendary", unlock: 900, unlockLevel: 16, cost: 600, desc: "Increases XP rewards from mission actions." },
  { id: "quantum", name: "Quantum Decoder", rarity: "Legendary", unlock: 1100, unlockLevel: 20, cost: 800, desc: "Adds elite-level cipher bonuses and rare reward events." }
];

const randomEvents = [
  { type: "reward", title: "Hidden backdoor discovered", text: "AI mapped an alternate route. Bonus XP acquired.", xp: 35, credits: 18 },
  { type: "reward", title: "Secret encrypted file found", text: "Optional data shard recovered from the target system.", xp: 45, credits: 22 },
  { type: "risk", title: "SECURITY BREACH DETECTED", text: "Trace pressure increased. Lockdown timer reduced.", penalty: 18 },
  { type: "risk", title: "AI intrusion detected", text: "Hostile AI probes your session. Stay sharp.", penalty: 10 },
  { type: "mixed", title: "Emergency lockdown initiated", text: "Risk spike survived. Combo reward granted.", xp: 25, penalty: 8 }
];

const stageNames = [
  "boot",
  "player-setup",
  "training",
  "password-firewall",
  "encryption",
  "network-scan",
  "command-terminal",
  "multi-security",
  "final-hack",
  "result"
];

const game = {
  user: "",
  stage: 1,
  mode: "Core Breach",
  score: 0,
  attempts: 0,
  failedAttempts: 0,
  hints: 0,
  correctActions: 0,
  totalActions: 0,
  startTime: null,
  countdown: 300,
  hackerId: "",
  codeName: "",
  difficulty: "Normal",
  firewallAttempts: 3,
  locked: false,
  commandIndex: 0,
  commandSequence: ["scan system", "decrypt", "access", "hack"],
  finalSuccess: false,
  ending: "failure",
  rivalScore: 0,
  mission: null,
  daily: null,
  xpEarned: 0,
  creditsEarned: 0,
  combo: 0,
  bestCombo: 0,
  bonusHints: 0,
  stageTotal: 10,
  puzzleIndex: 0,
  puzzleRun: false,
  puzzleSequence: [],
  modeConfig: null,
  usedExamples: {},
  eventStages: new Set(),
  sessionAchievements: new Set(),
  runToken: 0
};

const missions = [
  { target: "Central Intelligence Server", level: "MAXIMUM", file: "BLACKBOX-19" },
  { target: "Neon Grid Bank Vault", level: "HIGH", file: "LEDGER-ZERO" },
  { target: "Orbital Weather Array", level: "CRITICAL", file: "SKYBREACH" },
  { target: "Megacity Transit Core", level: "HIGH", file: "RAILGHOST" }
];

const caesarExamples = [
  ["KDFN", "HACK"], ["FRGH", "CODE"], ["ORJLQ", "LOGIN"], ["VHUYHU", "SERVER"],
  ["DFFHVV", "ACCESS"], ["QHWZRUN", "NETWORK"], ["SDVVZRUG", "PASSWORD"], ["HQFUBSW", "ENCRYPT"],
  ["YLUXV", "VIRUS"], ["PDOLZDUH", "MALWARE"], ["WUDFH", "TRACE"], ["NHUQHO", "KERNEL"],
  ["HASORLW", "EXPLOIT"], ["GDWDEDVH", "DATABASE"], ["ILUHZDOO", "FIREWALL"], ["FUBSWR", "CRYPTO"],
  ["SURWRFRO", "PROTOCOL"], ["WHUPLQDO", "TERMINAL"], ["ILOH", "FILE"], ["KDFNHU", "HACKER"]
].map(([encrypted, answer]) => ({
  type: "Caesar",
  encrypted,
  answer,
  hint: "Same shift = +3. Decode by moving each letter 3 steps backward."
}));

const vigenereExamples = [
  ["REAU", "HACK"], ["MSBO", "CODE"], ["VSESX", "LOGIN"], ["CIJZCB", "SERVER"],
  ["KGACWC", "ACCESS"], ["XIRGOWY", "NETWORK"], ["ZEQUAYVH", "PASSWORD"], ["ORMVWZX", "ENCRYPT"],
  ["FMPYW", "VIRUS"], ["QEPGEPV", "MALWARE"], ["DVCMO", "TRACE"], ["UIVRIP", "KERNEL"],
  ["IBZVSMD", "EXPLOIT"], ["NEXELCCO", "DATABASE"], ["PMPOAKPJ", "FIREWALL"], ["MVWZXM", "CRYPTO"],
  ["ZVMXSGYPJ", "PROTOCOL"], ["DIVQMERP", "TERMINAL"], ["PMJI", "FILE"], ["REAUOV", "HACKER"]
].map(([encrypted, answer]) => ({
  type: "Vigenere",
  encrypted,
  answer,
  hint: "Keyword = KEY. Use the same keyword to decode."
}));

const hardReverseExamples = [
  ["321KCAH", "HACK123"], ["drowssaPtoor", "rootPassword"], ["revreS_tsohG", "Ghost_Server"],
  ["99edoCyrtnE", "EntryCode99"], ["elif_gifnoc", "config_file"], ["tcennoCpeeD", "DeepConnect"],
  ["7tiolpxE", "Exploit7"], ["sseccA_nimdA", "Admin_Access"], ["yek_wodahS", "Shadow_key"],
  ["troP_844", "448_Port"], ["ecarTlluF", "FullTrace"], ["edoNkcalB", "BlackNode"],
  ["xiferPtoor", "rootPrefix"], ["pihCyruceS", "SecurityChip"], ["daolyaP_X", "X_Payload"],
  ["noitcejorPPI", "IPProjection"], ["46esabataD", "Database64"], ["tpyrCageM", "MegaCrypt"],
  ["edoMkcaH", "HackMode"], ["kcaBllaWeriF", "FirewallBack"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const memoryExamples = [
  "HACK-472", "ROOT_91", "NODE-X7", "KEY-8842", "LOGIN#22", "GhostNode_44",
  "SERVER-AX92", "Trace#7712", "CYBER_CORE7", "Firewall-X99", "ZX-41A-992-DELTA",
  "RootAccess#7741", "SHDW_KEY-887X", "VX-Core_19A7", "NET://X-442A", "Alpha7_Ghost#991",
  "SYS-OVERRIDE_44X", "DARK://NODE-77A", "XENO_HASH#2048", "KernelBypass_X9"
];

const binaryExamples = [
  ["01001000 01000001 01000011 01001011", "HACK"],
  ["01000011 01001111 01000100 01000101", "CODE"],
  ["01001100 01001111 01000111 01001001 01001110", "LOGIN"],
  ["01000110 01001001 01001100 01000101", "FILE"],
  ["01010010 01001111 01001111 01010100", "ROOT"],
  ["01001011 01000101 01011001", "KEY"],
  ["01010110 01001001 01010010 01010101 01010011", "VIRUS"],
  ["01001110 01001111 01000100 01000101", "NODE"],
  ["01010100 01010010 01000001 01000011 01000101", "TRACE"],
  ["01010000 01001111 01010010 01010100", "PORT"],
  ["01010011 01000101 01010010 01010110 01000101 01010010", "SERVER"],
  ["01000011 01011001 01000010 01000101 01010010", "CYBER"],
  ["01000011 01010010 01011001 01010000 01010100 01001111", "CRYPTO"],
  ["01010000 01001001 01001110", "PIN"],
  ["01000010 01001111 01010100", "BOT"],
  ["01000100 01000001 01010100 01000001", "DATA"],
  ["01000011 01001111 01010010 01000101", "CORE"],
  ["01001100 01001111 01000011 01001011", "LOCK"],
  ["01010011 01000011 01000001 01001110", "SCAN"],
  ["01010101 01010011 01000101 01010010", "USER"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const morseExamples = [
  [".... .- -.-. -.-", "HACK"], ["-.-. --- -.. .", "CODE"], [".-.. --- --. .. -.", "LOGIN"],
  ["... . .-. ...- . .-.", "SERVER"], [".-. --- --- -", "ROOT"], ["-.- . -.--", "KEY"],
  ["...- .. .-. ..- ...", "VIRUS"], ["-. --- -.. .", "NODE"], ["- .-. .- -.-. .", "TRACE"],
  [".--. --- .-. -", "PORT"], ["..-. .. .-.. .", "FILE"], ["-.-. -.-- -... . .-.", "CYBER"],
  ["-.-. .-. -.-- .--. - ---", "CRYPTO"], ["-.. .- - .-", "DATA"], ["-.-. --- .-. .", "CORE"],
  [".-.. --- -.-. -.-", "LOCK"], ["... -.-. .- -.", "SCAN"], ["..- ... . .-.", "USER"],
  [".-- .- .-.. .-..", "WALL"], [".--. .-.. .- -.", "PLAN"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const asciiConversionExamples = [
  ["72 65 67 75 69 82", "HACKER"],
  ["83 69 82 86 69 82", "SERVER"],
  ["68 65 84 65 66 65 83 69", "DATABASE"],
  ["70 73 82 69 87 65 76 76", "FIREWALL"],
  ["69 78 67 82 89 80 84", "ENCRYPT"],
  ["80 65 83 83 87 79 82 68", "PASSWORD"],
  ["78 69 84 87 79 82 75", "NETWORK"],
  ["80 82 79 84 79 67 79 76", "PROTOCOL"],
  ["84 69 82 77 73 78 65 76", "TERMINAL"],
  ["69 88 80 76 79 73 84", "EXPLOIT"],
  ["77 65 76 87 65 82 69", "MALWARE"],
  ["83 69 67 85 82 73 84 89", "SECURITY"],
  ["67 89 66 69 82 67 79 82 69", "CYBERCORE"],
  ["71 72 79 83 84 78 79 68 69", "GHOSTNODE"],
  ["82 79 79 84 65 67 67 69 83 83", "ROOTACCESS"],
  ["83 72 65 68 79 87 75 69 89", "SHADOWKEY"],
  ["66 76 65 67 75 79 85 84", "BLACKOUT"],
  ["79 86 69 82 82 73 68 69", "OVERRIDE"],
  ["84 82 65 67 69 82 79 85 84 69", "TRACEROUTE"],
  ["81 85 65 78 84 85 77 72 65 67 75", "QUANTUMHACK"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const hexadecimalConversionExamples = [
  ["48 41 43 4B 45 52", "HACKER"],
  ["53 45 52 56 45 52", "SERVER"],
  ["44 41 54 41 42 41 53 45", "DATABASE"],
  ["46 49 52 45 57 41 4C 4C", "FIREWALL"],
  ["45 4E 43 52 59 50 54", "ENCRYPT"],
  ["50 41 53 53 57 4F 52 44", "PASSWORD"],
  ["4E 45 54 57 4F 52 4B", "NETWORK"],
  ["50 52 4F 54 4F 43 4F 4C", "PROTOCOL"],
  ["54 45 52 4D 49 4E 41 4C", "TERMINAL"],
  ["45 58 50 4C 4F 49 54", "EXPLOIT"],
  ["4D 41 4C 57 41 52 45", "MALWARE"],
  ["53 45 43 55 52 49 54 59", "SECURITY"],
  ["43 59 42 45 52 43 4F 52 45", "CYBERCORE"],
  ["47 48 4F 53 54 4E 4F 44 45", "GHOSTNODE"],
  ["52 4F 4F 54 41 43 43 45 53 53", "ROOTACCESS"],
  ["53 48 41 44 4F 57 4B 45 59", "SHADOWKEY"],
  ["42 4C 41 43 4B 4F 55 54", "BLACKOUT"],
  ["4F 56 45 52 52 49 44 45", "OVERRIDE"],
  ["54 52 41 43 45 52 4F 55 54 45", "TRACEROUTE"],
  ["51 55 41 4E 54 55 4D 48 41 43 4B", "QUANTUMHACK"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const ipTrackerExamples = [
  ["11000000.10101000.00000001.00000001", "192.168.1.1"],
  ["11111111.11111111.11111111.00000000", "255.255.255.0"],
  ["10101100.00010000.00000001.00001010", "172.16.1.10"],
  ["10000000.00000000.00000000.00000001", "128.0.0.1"],
  ["11000000.10101000.00000000.00000001", "192.168.0.1"],
  ["00001010.00000000.00000000.00000001", "10.0.0.1"],
  ["01111111.00000000.00000000.00000001", "127.0.0.1"],
  ["11000000.10101000.00000001.01100100", "192.168.1.100"],
  ["11111111.00000000.11111111.00000000", "255.0.255.0"],
  ["11000000.10101000.00000010.00000010", "192.168.2.2"],
  ["10101010.10101010.10101010.10101010", "170.170.170.170"],
  ["00000001.00000010.00000011.00000100", "1.2.3.4"],
  ["11110000.11110000.11110000.11110000", "240.240.240.240"],
  ["00110010.01010100.01110110.10011000", "50.84.118.152"],
  ["10000001.10000010.10000011.10000100", "129.130.131.132"],
  ["00001111.00001111.00001111.00001111", "15.15.15.15"],
  ["11001010.11111110.10111010.10111110", "202.254.186.190"],
  ["01100100.01001000.00110010.00010100", "100.72.50.20"],
  ["11100000.00010000.00001000.00000100", "224.16.8.4"],
  ["00101010.00101010.00101010.00101010", "42.42.42.42"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const base64Examples = [
  ["SEFDSw==", "HACK"],
  ["Q09ERQ==", "CODE"],
  ["TE9HSU4=", "LOGIN"],
  ["U0VSVkVS", "SERVER"],
  ["Uk9PVA==", "ROOT"],
  ["S0VZ", "KEY"],
  ["VklSVVM=", "VIRUS"],
  ["Tk9ERQ==", "NODE"],
  ["VFJBQ0U=", "TRACE"],
  ["UE9SVA==", "PORT"],
  ["RklMRQ==", "FILE"],
  ["Q1lCRVI=", "CYBER"],
  ["Q1JZUFRP", "CRYPTO"],
  ["REFUQQ==", "DATA"],
  ["Q09SRQ==", "CORE"],
  ["TE9DSw==", "LOCK"],
  ["U0NBTg==", "SCAN"],
  ["VVNFUg==", "USER"],
  ["RklSRVdBTEw=", "FIREWALL"],
  ["UEFTU1dPUkQ=", "PASSWORD"]
].map(([encrypted, answer]) => ({ encrypted, answer }));

const debugExamples = [
  {
    title: "LOGIN TERMINAL",
    answer: "10",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      string password = "root";
6      string input;
7
8      cin >> input;
9
10     if(input = password)
11         cout << "ACCESS GRANTED";
12     else
13         cout << "ACCESS DENIED";
14 }`
  },
  {
    title: "FIREWALL CHECK",
    answer: "10",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      int port = 80;
6
7      if(port == 80)
8          cout << "HTTP OPEN";
9
10     retrn 0;
11 }`
  },
  {
    title: "VIRUS SCANNER",
    answer: "7",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      int infectedFiles = 5;
6
7      while(infectedFiles > 0) {
8          cout << "Deleting Virus..." << endl;
9      }
10 }`
  },
  {
    title: "SERVER ACCESS",
    answer: "7",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      int accessLevel = 7;
6
7      if(accessLevel >= 5);
8          cout << "SERVER UNLOCKED";
9
10     return 0;
11 }`
  },
  {
    title: "IP LOGGER",
    answer: "9",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      int ip[4] = {192,168,1,1};
6
7      cout << ip[0] << ".";
8      cout << ip[1] << ".";
9      cout << ip[4];
10 }`
  },
  {
    title: "PASSWORD GENERATOR",
    answer: "5",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      int length = 8
6
7      cout << "Generating Password...";
8
9      return 0;
10 }`
  },
  {
    title: "DATA ENCRYPTOR",
    answer: "9",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      char letter = 'A';
6
7      letter = letter + 3;
8
9      cout << encrypted;
10 }`
  },
  {
    title: "NETWORK SCAN",
    answer: "5",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      for(int i = 1; i <= 5; i++);
6      {
7          cout << "Scanning Port " << i << endl;
8      }
9
10     return 0;
11 }`
  },
  {
    title: "ACCESS KEY CHECK",
    answer: "11",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      int key;
6
7      cin >> key;
8
9      if(key == 9999)
10         cout << "SAFE OPENED";
11     esle
12         cout << "WRONG KEY";
13 }`
  },
  {
    title: "FILE DECRYPTOR",
    answer: "9",
    code: `1  #include <iostream>
2  using namespace std;
3
4  int main() {
5      string file = "secret.txt";
6
7      cout << "Decrypting " << file << endl;
8
9      int code = 10 / 0;
10
11     return 0;
12 }`
  }
];

const passwordProfileExamples = [
  {
    title: "PROFILE 1",
    answer: "Rocky98",
    info: `Name        : Amit
Pet         : Rocky
Birth Year  : 1998
Bike        : Pulsar`
  },
  {
    title: "PROFILE 2",
    answer: "Valorant21",
    info: `Name            : Neha
Favorite Game   : Valorant
Lucky Number    : 21
City            : Delhi`
  },
  {
    title: "PROFILE 3",
    answer: "Bruno2001",
    info: `Name        : Rohan
Dog         : Bruno
Car         : Swift
DOB         : 2001`
  },
  {
    title: "PROFILE 4",
    answer: "KTM14",
    info: `Name            : Karan
Instagram ID    : KaranLive
Favorite Bike   : KTM
Birth Date      : 14`
  },
  {
    title: "PROFILE 5",
    answer: "OreoBlack",
    info: `Name            : Simran
Pet Cat         : Oreo
Favorite Color  : Black
Year            : 2005`
  },
  {
    title: "PROFILE 6",
    answer: "ShadowX99",
    info: `Name          : Aryan
Gaming ID     : ShadowX
Lucky Number  : 99
Bike          : R15`
  },
  {
    title: "PROFILE 7",
    answer: "Coco4421",
    info: `Name          : Priya
School        : Sunrise Public
Pet Name      : Coco
Car Number    : 4421`
  },
  {
    title: "PROFILE 8",
    answer: "Anonymous97",
    info: `Name             : Dev
Favorite Hacker  : Anonymous
Laptop Brand     : HP
Birth Year       : 1997`
  },
  {
    title: "PROFILE 9",
    answer: "Ghost404",
    info: `Name             : Rahul
Nickname         : Ghost
Favorite Number  : 404
Pet              : Max`
  },
  {
    title: "PROFILE 10",
    answer: "Activa2003",
    info: `Name            : Tanya
Scooty          : Activa
Favorite App    : Instagram
DOB             : 2003`
  }
];

const logicGateExamples = [
  ["0", "0", "AND", "0"], ["0", "1", "AND", "0"], ["1", "0", "AND", "0"], ["1", "1", "AND", "1"],
  ["0", "0", "OR", "0"], ["0", "1", "OR", "1"], ["1", "0", "OR", "1"], ["1", "1", "OR", "1"],
  ["0", "0", "XOR", "0"], ["0", "1", "XOR", "1"], ["1", "0", "XOR", "1"], ["1", "1", "XOR", "0"],
  ["0", "0", "NAND", "1"], ["0", "1", "NAND", "1"], ["1", "0", "NAND", "1"], ["1", "1", "NAND", "0"],
  ["0", "0", "NOR", "1"], ["0", "1", "NOR", "0"], ["1", "0", "XNOR", "0"], ["1", "1", "XNOR", "1"]
].map(([a, b, gate, answer]) => ({ a, b, gate, answer }));

const patternExamples = [
  ["2 4 6 8 ?", "10"], ["5 10 15 20 ?", "25"], ["1 4 9 16 ?", "25"], ["3 6 12 24 ?", "48"],
  ["A C E G ?", "I"], ["B D F H ?", "J"], ["Z X V T ?", "R"], ["A1 B2 C3 D4 ?", "E5"],
  ["H1 J2 L3 N4 ?", "P5"], ["X2 W4 V6 U8 ?", "T10"], ["AA AB AC AD ?", "AE"], ["M1 O2 Q3 S4 ?", "U5"],
  ["10 20 30 40 ?", "50"], ["81 27 9 3 ?", "1"], ["C4 E8 G12 I16 ?", "K20"], ["A Z B Y C X ?", "D"],
  ["7 14 21 28 ?", "35"], ["2 3 5 8 13 ?", "21"], ["K L N Q U ?", "Z"], ["1A 2B 3C 4D ?", "5E"]
].map(([prompt, answer]) => ({ prompt, answer }));

const speedTypingExamples = [
  ["ACCESS GRANTED", 10], ["ROOT ACCESS ENABLED", 10], ["FIREWALL BYPASSED", 10], ["TRACE DETECTED RUN", 10],
  ["SERVER CONNECTION LOST", 10], ["INITIATE OVERRIDE", 10], ["SYSTEM BREACH ACTIVE", 10], ["HACK THE MAINFRAME", 10],
  ["ENCRYPTION KEY FOUND", 10], ["UPLOADING VIRUS FILE", 10], ["SCANNING OPEN PORTS", 10], ["LOGIN AUTH SUCCESS", 10],
  ["TERMINAL OVERRIDE NOW", 10], ["SECURITY SYSTEM DOWN", 10], ["NETWORK ACCESS OPEN", 10], ["DECRYPT SECRET FILE", 10],
  ["MALWARE INJECTION START", 10], ["EXECUTE SHADOW PROTOCOL", 10], ["DISABLE TRACE MODULE", 10], ["EMERGENCY SYSTEM SHUTDOWN", 10]
].map(([phrase, seconds]) => ({ phrase, seconds }));

const cipherBank = [...caesarExamples, ...vigenereExamples];

const puzzleStages = [
  { id: "memory", name: "Memory Hack", desc: "Memorize a short access sequence before it vanishes." },
  { id: "guess", name: "Guess the Number", desc: "Infer the hidden number from terminal feedback." },
  { id: "caesar", name: "Caesar Cipher", desc: "Decode a +3 shifted encrypted word." },
  { id: "vigenere", name: "Vigenere Cipher", desc: "Decode a keyword-based encrypted word." },
  { id: "ports", name: "Port Select", desc: "Select the safe OPEN route from a scan." },
  { id: "prompt", name: "Prompt Command", desc: "Type the required terminal command sequence." },
  { id: "reverse", name: "Reverse Cipher", desc: "Reverse an encrypted payload into readable text." },
  { id: "ascii", name: "ASCII Conversion", desc: "Decode decimal ASCII values into a cyber word." },
  { id: "hex", name: "Hexadecimal Conversion", desc: "Decode hexadecimal ASCII bytes into a cyber word." },
  { id: "ip", name: "IP Tracker", desc: "Convert binary octets into a dotted decimal IP address." },
  { id: "base64", name: "Base64", desc: "Decode a Base64 payload into readable text." },
  { id: "binary", name: "Binary Translation", desc: "Translate binary bytes into letters." },
  { id: "morse", name: "Morse Code", desc: "Decode a short Morse transmission." },
  { id: "debug", name: "Debug", desc: "Find the bugged line number in a C++ snippet." },
  { id: "password-profile", name: "Password Profiling", desc: "Use profile clues to guess the likely password." },
  { id: "logic", name: "Logic Gate", desc: "Solve a boolean gate output." },
  { id: "pattern", name: "Pattern Prediction", desc: "Predict the next value in a security pattern." },
  { id: "speed", name: "Speed Typing", desc: "Type the command phrase before the timer expires." }
];

function getUsers() {
  return JSON.parse(localStorage.getItem("hts-users") || "{}");
}

function saveUsers(users) {
  localStorage.setItem("hts-users", JSON.stringify(users));
}

function getProfile(username) {
  const users = getUsers();
  return normalizeProfile(users[username]?.profile || createDefaultProfile(username), username);
}

function createDefaultProfile(username) {
  return {
    username,
    codeName: "",
    rank: "Rookie",
    level: 1,
    xp: 0,
    credits: 100,
    bestScore: 0,
    lastScore: 0,
    stage: 1,
    attempts: 0,
    accuracy: 0,
    fastestTime: null,
    achievements: [],
    badges: [],
    matchHistory: [],
    friends: ["ZeroTrace", "ByteLynx"],
    dailyStreak: 0,
    lastDaily: "",
    lastLogin: "",
    bonusHints: 0,
    missionsCompleted: 0,
    dailyChallengesCompleted: 0,
    performance: {
      bestAccuracy: 0,
      bestCombo: 0,
      fastestWin: null,
      totalRuns: 0,
      totalWins: 0
    },
    toolLevels: { decryptor: 1, scanner: 1 },
    tools: ["decryptor", "scanner"]
  };
}

function normalizeProfile(profile, username) {
  const defaults = createDefaultProfile(username);
  const merged = { ...defaults, ...profile };

  merged.username = username;
  merged.achievements = Array.isArray(merged.achievements) ? merged.achievements : [];
  merged.badges = Array.isArray(merged.badges) ? merged.badges : [];
  merged.matchHistory = Array.isArray(merged.matchHistory) ? merged.matchHistory : [];
  merged.performance = merged.performance || {
    bestAccuracy: 0,
    bestCombo: 0,
    fastestWin: null,
    totalRuns: 0,
    totalWins: 0
  };
  merged.friends = Array.isArray(merged.friends) ? merged.friends : defaults.friends;
  merged.tools = Array.isArray(merged.tools) ? Array.from(new Set([...defaults.tools, ...merged.tools])) : defaults.tools;
  merged.toolLevels = { ...defaults.toolLevels, ...(merged.toolLevels || {}) };
  merged.level = getLevelFromXp(merged.xp || 0);
  merged.credits = Number.isFinite(merged.credits) ? merged.credits : defaults.credits;
  merged.bonusHints = Number.isFinite(merged.bonusHints) ? merged.bonusHints : 0;
  merged.missionsCompleted = Number.isFinite(merged.missionsCompleted) ? merged.missionsCompleted : 0;
  merged.dailyChallengesCompleted = Number.isFinite(merged.dailyChallengesCompleted) ? merged.dailyChallengesCompleted : 0;

  return merged;
}

function updateProfile(mutator) {
  const users = getUsers();
  const profile = normalizeProfile(users[game.user]?.profile || createDefaultProfile(game.user), game.user);
  mutator(profile);
  profile.level = getLevelFromXp(profile.xp);
  users[game.user].profile = profile;
  saveUsers(users);
  return profile;
}

function setAuthMode(mode) {
  authMode = mode;
  loginTab.classList.toggle("active", mode === "login");
  signupTab.classList.toggle("active", mode === "signup");
  authSubmit.textContent = mode === "login" ? "Login" : "Create Account";
  authMessage.textContent = "";
}

loginTab.addEventListener("click", () => setAuthMode("login"));
signupTab.addEventListener("click", () => setAuthMode("signup"));
logoutButton.addEventListener("click", () => {
  clearTimers();
  clearRuntimeTimers();
  game.user = "";
  lobbyScreen.classList.remove("active");
  gameScreen.classList.remove("active");
  authScreen.classList.add("active");
  setAuthMode("login");
});

mainMenuButton.addEventListener("click", () => returnToMainMenu());

document.addEventListener("keydown", event => {
  if (!gameScreen.classList.contains("active")) return;

  const tag = event.target?.tagName;
  const isEditing = tag === "INPUT" || tag === "TEXTAREA" || event.target?.isContentEditable;
  const wantsBack = event.key === "Escape" || (event.key === "Backspace" && !isEditing);

  if (!wantsBack) return;
  event.preventDefault();
  returnToMainMenu();
});

document.querySelectorAll(".nav-button").forEach(button => {
  button.addEventListener("click", () => {
    currentPanel = button.dataset.panel;
    document.querySelectorAll(".nav-button").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    renderLobbyPanel();
  });
});

authForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  const users = getUsers();

  if (!/^[a-zA-Z0-9_]{3,16}$/.test(username)) {
    authMessage.textContent = "Username must be 3-16 letters, numbers, or underscores.";
    return;
  }

  if (password.length < 4) {
    authMessage.textContent = "Password must be at least 4 characters.";
    return;
  }

  if (authMode === "signup") {
    if (users[username]) {
      authMessage.textContent = "Username already exists.";
      return;
    }

    users[username] = { password, profile: createDefaultProfile(username) };
    saveUsers(users);
    authMessage.textContent = "Account created. Access channel ready.";
    setAuthMode("login");
    return;
  }

  if (!users[username] || users[username].password !== password) {
    authMessage.textContent = "Invalid username or password.";
    return;
  }

  game.user = username;
  const streakReward = processDailyLogin(username);
  showLobby(streakReward);
});

function showLobby(streakReward = null) {
  const profile = getProfile(game.user);
  lobbyName.textContent = profile.codeName || profile.username;
  lobbyRank.textContent = `Rank: ${profile.rank}`;
  lobbyLevel.textContent = `Level ${profile.level}`;
  lobbyStreak.textContent = `${profile.dailyStreak}-Day Hacking Streak`;
  lobbyCredits.textContent = `Credits: ${profile.credits}`;
  authScreen.classList.remove("active");
  gameScreen.classList.remove("active");
  lobbyScreen.classList.add("active");
  renderLobbyPanel();

  if (streakReward) {
    showRewardBurst(`${streakReward.streak}-Day Streak`, `+${streakReward.xp} XP  +${streakReward.credits} credits`);
    if (streakReward.streak >= 3) unlockAchievement("streak");
  }
}

function beginRuntime() {
  game.runToken++;
  clearTimers();
  clearRuntimeTimers();
}

function returnToMainMenu(showNotice = true) {
  beginRuntime();
  saveProgress();
  game.puzzleRun = false;
  game.modeConfig = null;
  game.locked = false;
  terminalOutput.innerHTML = "";
  interactiveZone.innerHTML = "";
  showLobby();
  if (showNotice) showRewardBurst("Returned To Main Menu", "Current operation stopped safely.");
}

function scheduleTimeout(callback, delay) {
  const token = game.runToken;
  const id = setTimeout(() => {
    runtimeTimeouts.delete(id);
    if (token === game.runToken) callback();
  }, delay);
  runtimeTimeouts.add(id);
  return id;
}

function scheduleInterval(callback, delay) {
  const token = game.runToken;
  const id = setInterval(() => {
    if (token !== game.runToken) {
      clearInterval(id);
      runtimeIntervals.delete(id);
      return;
    }
    callback();
  }, delay);
  runtimeIntervals.add(id);
  return id;
}

function clearRuntimeTimers() {
  runtimeTimeouts.forEach(id => clearTimeout(id));
  runtimeIntervals.forEach(id => clearInterval(id));
  runtimeTimeouts.clear();
  runtimeIntervals.clear();
}

function processDailyLogin(username) {
  const today = new Date();
  const todayKey = toDateKey(today);
  let reward = null;

  game.user = username;
  updateProfile(profile => {
    if (profile.lastLogin === todayKey) return;

    const previous = profile.lastLogin ? new Date(`${profile.lastLogin}T00:00:00`) : null;
    const dayGap = previous ? Math.round((today - previous) / 86400000) : 1;
    profile.dailyStreak = dayGap === 1 ? profile.dailyStreak + 1 : 1;
    profile.lastLogin = todayKey;

    const xp = 40 + profile.dailyStreak * 10;
    const credits = 25 + profile.dailyStreak * 5;
    profile.xp += xp;
    profile.credits += credits;

    if (profile.dailyStreak % 3 === 0) {
      profile.bonusHints += 1;
    }

    if (profile.dailyStreak >= 5 && !profile.tools.includes("hintUnlocker")) {
      profile.tools.push("hintUnlocker");
      profile.toolLevels.hintUnlocker = 1;
    }

    reward = { streak: profile.dailyStreak, xp, credits };
  });

  return reward;
}

function renderHowToRuleCard(card) {
  const rulesId = `rules-${card.id}`;
  return `
    <div class="info-card rule-card">
      <div class="rule-card-head">
        <h3>${card.title}</h3>
        <button class="mini-button rule-toggle" type="button" data-rules-target="${rulesId}" aria-controls="${rulesId}" aria-expanded="false">Rules</button>
      </div>
      <pre id="${rulesId}" class="rule-text" hidden>${card.rules}</pre>
    </div>
  `;
}

function bindHowToRuleButtons() {
  document.querySelectorAll(".rule-toggle").forEach(button => {
    button.addEventListener("click", () => {
      const rules = document.getElementById(button.dataset.rulesTarget);
      if (!rules) return;

      const shouldOpen = rules.hidden;
      rules.hidden = !shouldOpen;
      button.setAttribute("aria-expanded", String(shouldOpen));
    });
  });
}

function renderLobbyPanel() {
  const profile = getProfile(game.user);
  const daily = getDailyChallenge();

  if (currentPanel === "how-to") {
    lobbyContent.innerHTML = `
      <h2>How To Play</h2>
      <div class="info-grid how-to-rules-grid">
        ${howToRuleCards.map(renderHowToRuleCard).join("")}
      </div>
    `;
    bindHowToRuleButtons();
    return;
  }

  if (currentPanel === "modes") {
    lobbyContent.innerHTML = `
      <h2>Game Modes</h2>
      <div class="mode-grid">
        ${Object.entries(modes).map(([name]) => `
          <div class="mode-card ${game.mode === name ? "active-mode" : ""}">
            <h3>${name}</h3>
            <button class="mode-button" data-mode="${name}" type="button">Enter ${name}</button>
          </div>
        `).join("")}
      </div>
    `;
    document.querySelectorAll(".mode-button").forEach(button => {
      button.addEventListener("click", () => startModeRun(button.dataset.mode));
    });
    return;
  }

  if (currentPanel === "daily") {
    lobbyContent.innerHTML = `
      <h2>Daily Challenges & Events</h2>
      <div class="event-card">
        <h3>${daily.name}</h3>
        <p>Target: ${daily.target}</p>
        <p>Modifier: ${daily.modifier}</p>
        <p>Objective: ${daily.objective}</p>
        <p>Event timer: ${daily.timer}</p>
        <p>Reward: ${daily.reward} XP, ${daily.credits} credits, and streak progress.</p>
      </div>
      <div class="control-grid" style="margin-top: 16px;">
        <button class="primary-button" id="start-daily" type="button">Start Daily Operation</button>
        <button class="ghost-button" id="claim-daily" type="button">Claim Practice Reward</button>
      </div>
    `;
    document.getElementById("start-daily").addEventListener("click", () => startGame("Challenge", daily));
    document.getElementById("claim-daily").addEventListener("click", () => {
      const today = new Date().toISOString().slice(0, 10);
      const updated = updateProfile(item => {
        if (item.lastDaily !== today) {
          item.dailyStreak++;
          item.lastDaily = today;
          item.xp += daily.reward;
          item.credits += daily.credits;
          item.dailyChallengesCompleted++;
        }
      });
      lobbyStreak.textContent = `${updated.dailyStreak}-Day Hacking Streak`;
      lobbyCredits.textContent = `Credits: ${updated.credits}`;
      showRewardBurst("Daily Reward", `+${daily.reward} XP  +${daily.credits} credits`);
    });
    return;
  }

  if (currentPanel === "puzzles") {
    lobbyContent.innerHTML = `
      <h2>Puzzle Lab</h2>
      ${renderProgressHeader(profile)}
      <p class="muted">Select any games, choose a time limit, then start the custom run.</p>
      <form id="custom-puzzle-form" autocomplete="off">
        <div class="info-grid puzzle-select-grid">
          ${puzzleStages.map((puzzle, index) => `
            <label class="info-card puzzle-option" for="puzzle-option-${puzzle.id}">
              <span class="puzzle-card-head">
                <input class="puzzle-checkbox" id="puzzle-option-${puzzle.id}" name="puzzle-game" type="checkbox" value="${puzzle.id}">
                <span>${String(index + 1).padStart(2, "0")}</span>
              </span>
              <h3>${puzzle.name}</h3>
              <p>${puzzle.desc}</p>
            </label>
          `).join("")}
        </div>
        <div class="time-limit-panel">
          <h3>Time Limit</h3>
          <div class="time-option-grid">
            <label class="time-option"><input name="puzzle-time" type="radio" value="120">2 min</label>
            <label class="time-option"><input name="puzzle-time" type="radio" value="300" checked>5 min</label>
            <label class="time-option"><input name="puzzle-time" type="radio" value="600">10 min</label>
            <label class="time-option"><input name="puzzle-time" type="radio" value="900">15 min</label>
            <label class="time-option"><input name="puzzle-time" type="radio" value="endless">Endless</label>
          </div>
        </div>
        <button class="primary-button" id="start-custom-puzzle" type="submit">Start</button>
        <p class="message" id="puzzle-config-message"></p>
      </form>
    `;
    document.getElementById("custom-puzzle-form").addEventListener("submit", event => {
      event.preventDefault();
      const selectedGames = Array.from(document.querySelectorAll('input[name="puzzle-game"]:checked')).map(input => input.value);
      const selectedTime = document.querySelector('input[name="puzzle-time"]:checked')?.value || "300";
      const message = document.getElementById("puzzle-config-message");

      if (selectedGames.length === 0) {
        message.textContent = "Select at least one game before starting.";
        return;
      }

      startPuzzleLab({
        games: selectedGames,
        timeLimit: selectedTime === "endless" ? null : Number(selectedTime)
      });
    });
    return;
  }

  if (currentPanel === "shop") {
    renderShopPanel(profile);
    return;
  }

  if (currentPanel === "multiplayer") {
    const rivals = buildRivals(profile);
    lobbyContent.innerHTML = `
      <h2>Multiplayer Simulation</h2>
      <div class="info-grid">
        <div class="info-card"><h3>PvP Battle</h3><p>Race a simulated hacker rival with real-time score comparison during your run.</p></div>
        <div class="info-card"><h3>Co-op Mission</h3><p>AI partner assists with hints and route tracing while you complete objectives.</p></div>
        <div class="info-card"><h3>Online/Offline</h3><p>Local simulation works offline. Online status panels are mocked for localhost play.</p></div>
      </div>
      <h3 style="margin-top: 16px;">Matchmaking Queue</h3>
      <div class="leaderboard-grid">
        ${rivals.map(rival => `<div class="leader-card"><strong>${rival.name}</strong><br>Rank ${rival.rank}<br>Score ${rival.score}</div>`).join("")}
      </div>
      <div class="control-grid" style="margin-top: 16px;">
        <button class="primary-button" id="start-pvp" type="button">Start PvP Battle</button>
        <button class="ghost-button" id="start-coop" type="button">Start Co-op Mission</button>
      </div>
    `;
    document.getElementById("start-pvp").addEventListener("click", () => startGame("Story", null, "PvP"));
    document.getElementById("start-coop").addEventListener("click", () => startGame("Training", null, "Co-op"));
    return;
  }

  if (currentPanel === "leaderboard") {
    const board = getLeaderboard(profile);
    lobbyContent.innerHTML = `
      <h2>Leaderboard</h2>
      <div class="leaderboard-grid">
        ${board.map((row, index) => `
          <div class="leader-card">
            <strong>#${index + 1} ${row.name}</strong><br>
            Score ${row.score}<br>
            Accuracy ${row.accuracy}%<br>
            Attempts ${row.attempts}<br>
            Fastest ${row.time}
          </div>
        `).join("")}
      </div>
    `;
    return;
  }

  if (currentPanel === "analytics") {
    renderAnalyticsPanel(profile);
    return;
  }

  lobbyContent.innerHTML = `
    <h2>Player Profile</h2>
    ${renderProgressHeader(profile)}
    <div class="stats-grid">
      <div class="stat-card"><h3>Level</h3><p>${profile.level}</p></div>
      <div class="stat-card"><h3>XP</h3><p>${profile.xp}</p></div>
      <div class="stat-card"><h3>Credits</h3><p>${profile.credits}</p></div>
      <div class="stat-card"><h3>Best Score</h3><p>${profile.bestScore}</p></div>
      <div class="stat-card"><h3>Last Score</h3><p>${profile.lastScore}</p></div>
      <div class="stat-card"><h3>Saved Stage</h3><p>${profile.stage}/10</p></div>
      <div class="stat-card"><h3>Attempts</h3><p>${profile.attempts}</p></div>
      <div class="stat-card"><h3>Accuracy</h3><p>${profile.accuracy}%</p></div>
      <div class="stat-card"><h3>Missions</h3><p>${profile.missionsCompleted}</p></div>
      <div class="stat-card"><h3>Bonus Hints</h3><p>${profile.bonusHints}</p></div>
      <div class="stat-card"><h3>Friends</h3><p>${profile.friends.join(", ")}</p></div>
    </div>
    <h3 style="margin-top: 18px;">Inventory Tools</h3>
    <div class="tool-grid">
      ${tools.map(tool => `<div class="tool-card ${profile.tools.includes(tool.id) ? "unlocked" : ""}"><strong>${tool.name}</strong><br>${tool.rarity}<br>${profile.tools.includes(tool.id) ? `Level ${profile.toolLevels[tool.id] || 1}` : `Unlock at Level ${tool.unlockLevel}`}</div>`).join("")}
    </div>
    <h3 style="margin-top: 18px;">Achievements</h3>
    <div class="tool-grid">
      ${Object.values(achievements).map(item => `<div class="tool-card ${profile.achievements.includes(item.name) ? "unlocked" : ""}"><strong>${item.name}</strong><br>${item.text}</div>`).join("")}
    </div>
  `;
}

function renderProgressHeader(profile) {
  const progress = getXpProgress(profile.xp);
  const rankProgress = getRankProgress(profile);

  return `
    <div class="progress-module">
      <div class="progress-title">
        <strong>Level ${profile.level}</strong>
        <span>${progress.current}/${progress.required} XP to Level ${profile.level + 1}</span>
      </div>
      <div class="progress xp-bar"><span style="--value: ${progress.percent}%;"></span></div>
      <div class="progress-title">
        <strong>${profile.rank}</strong>
        <span>${rankProgress.percent}% toward ${rankProgress.next}</span>
      </div>
      <div class="progress rank-bar"><span style="--value: ${rankProgress.percent}%;"></span></div>
    </div>
  `;
}

function renderShopPanel(profile) {
  lobbyContent.innerHTML = `
    <h2>Black Market Shop</h2>
    ${renderProgressHeader(profile)}
    <div class="status-strip">
      <span class="status-pill">Credits: <strong>${profile.credits}</strong></span>
      <span class="status-pill">Buyer level: <strong>${profile.level}</strong></span>
      <span class="status-pill">Inventory slots: <strong>${profile.tools.length}</strong></span>
    </div>
    <div class="shop-grid">
      ${tools.filter(tool => tool.cost > 0).map(tool => {
        const owned = profile.tools.includes(tool.id);
        const level = profile.toolLevels[tool.id] || 0;
        const locked = profile.level < tool.unlockLevel;
        const price = getToolPrice(tool, level);
        return `
          <div class="shop-card ${owned ? "unlocked" : ""} ${locked ? "locked" : ""}">
            <div class="shop-card-head">
              <strong>${tool.name}${owned ? ` v${level}` : ""}</strong>
              <span>${tool.rarity}</span>
            </div>
            <p>${tool.desc}</p>
            <p>${locked ? `Requires Level ${tool.unlockLevel}` : `${price} credits`}</p>
            <div class="control-grid">
              <button class="mode-button buy-tool" data-tool="${tool.id}" type="button" ${locked ? "disabled" : ""}>${owned ? "Upgrade" : "Buy"}</button>
              <button class="ghost-button sell-tool" data-tool="${tool.id}" type="button" ${!owned ? "disabled" : ""}>Sell</button>
            </div>
          </div>
        `;
      }).join("")}
    </div>
  `;

  document.querySelectorAll(".buy-tool").forEach(button => {
    button.addEventListener("click", () => buyTool(button.dataset.tool));
  });
  document.querySelectorAll(".sell-tool").forEach(button => {
    button.addEventListener("click", () => sellTool(button.dataset.tool));
  });
}

function renderAnalyticsPanel(profile) {
  const analytics = getPerformanceAnalytics(profile);

  lobbyContent.innerHTML = `
    <h2>Performance Analytics</h2>
    ${renderProgressHeader(profile)}
    <div class="analytics-grid">
      <div class="analytics-card"><strong>Performance Grade</strong><span>${analytics.grade}</span></div>
      <div class="analytics-card"><strong>Win Rate</strong><span>${analytics.winRate}%</span></div>
      <div class="analytics-card"><strong>Best Accuracy</strong><span>${analytics.bestAccuracy}%</span></div>
      <div class="analytics-card"><strong>Average Score</strong><span>${analytics.averageScore}</span></div>
      <div class="analytics-card"><strong>Fastest Win</strong><span>${analytics.fastestWin}</span></div>
      <div class="analytics-card"><strong>Best Combo</strong><span>${analytics.bestCombo}x</span></div>
    </div>
    <div class="progress-module" style="margin-top: 16px;">
      <div class="progress-title"><strong>Accuracy Stability</strong><span>${analytics.bestAccuracy}%</span></div>
      <div class="progress analytics-bar"><span style="--value: ${analytics.bestAccuracy}%;"></span></div>
      <div class="progress-title"><strong>Mission Consistency</strong><span>${analytics.winRate}%</span></div>
      <div class="progress analytics-bar"><span style="--value: ${analytics.winRate}%;"></span></div>
    </div>
    <div class="event-card">
      <h3>Next Recommended Goal</h3>
      <p>${analytics.recommendation}</p>
    </div>
    <h3 style="margin-top: 18px;">Recent Runs</h3>
    <div class="leaderboard-grid">
      ${(profile.matchHistory.length ? profile.matchHistory : [{ mode: "No runs yet", score: 0, rank: profile.rank, result: "pending", accuracy: 0, attempts: 0 }]).map(run => `
        <div class="leader-card">
          <strong>${run.mode}</strong><br>
          Result ${run.result}<br>
          Score ${run.score}<br>
          Accuracy ${run.accuracy || 0}%<br>
          Attempts ${run.attempts || 0}<br>
          Rank ${run.rank}
        </div>
      `).join("")}
    </div>
  `;
}

function getPerformanceAnalytics(profile) {
  const history = profile.matchHistory || [];
  const totalRuns = profile.performance?.totalRuns || history.length;
  const totalWins = profile.performance?.totalWins || history.filter(run => run.result === "win").length;
  const averageScore = history.length
    ? Math.round(history.reduce((total, run) => total + (run.score || 0), 0) / history.length)
    : profile.lastScore;
  const winRate = totalRuns ? Math.round((totalWins / totalRuns) * 100) : 0;
  const bestAccuracy = Math.max(profile.performance?.bestAccuracy || 0, profile.accuracy || 0);
  const fastestWin = profile.performance?.fastestWin === null || profile.performance?.fastestWin === undefined
    ? "--:--"
    : formatTime(profile.performance.fastestWin);

  return {
    averageScore,
    winRate,
    bestAccuracy,
    fastestWin,
    bestCombo: profile.performance?.bestCombo || 0,
    grade: getPerformanceGrade(averageScore, winRate, bestAccuracy),
    recommendation: getNextRecommendedGoal(profile, averageScore, winRate, bestAccuracy)
  };
}

function getPerformanceGrade(averageScore, winRate, accuracy) {
  const value = averageScore * 0.04 + winRate * 0.35 + accuracy * 0.35;
  if (value >= 95) return "S+";
  if (value >= 82) return "A";
  if (value >= 68) return "B";
  if (value >= 52) return "C";
  return "D";
}

function getNextRecommendedGoal(profile, averageScore, winRate, accuracy) {
  if (accuracy < 75) return "Improve accuracy by using status/help commands before risky actions.";
  if (winRate < 60) return "Finish one Core Breach run successfully to stabilize your win rate.";
  if (profile.level < 5) return "Reach Level 5 to unlock stronger Black Market rewards.";
  if (averageScore < 900) return "Push for a 900+ score by chaining combos and avoiding hints.";
  return "Attempt a no-hint stealth run to climb toward Cyber Phantom.";
}

function buyTool(id) {
  const tool = tools.find(item => item.id === id);
  if (!tool) return;
  let purchased = false;
  let deniedReason = "";

  const profile = updateProfile(item => {
    const level = item.toolLevels[id] || 0;
    const price = getToolPrice(tool, level);
    if (item.level < tool.unlockLevel || item.credits < price) {
      deniedReason = item.level < tool.unlockLevel ? `Requires Level ${tool.unlockLevel}` : "Not enough credits";
      return;
    }

    item.credits -= price;
    if (!item.tools.includes(id)) item.tools.push(id);
    item.toolLevels[id] = level + 1;
    if (id === "hintUnlocker") item.bonusHints += 1;
    purchased = true;
  });

  lobbyCredits.textContent = `Credits: ${profile.credits}`;
  if (!purchased) {
    showRewardBurst("Market Denied", deniedReason);
    renderShopPanel(profile);
    return;
  }

  unlockAchievement("shopper");
  showRewardBurst("Tool Unlocked", tool.name);
  renderShopPanel(profile);
}

function sellTool(id) {
  const tool = tools.find(item => item.id === id);
  if (!tool || tool.cost === 0) return;

  const profile = updateProfile(item => {
    if (!item.tools.includes(id)) return;
    const level = item.toolLevels[id] || 1;
    item.credits += Math.max(20, Math.floor(getToolPrice(tool, level - 1) * 0.45));
    item.toolLevels[id] = Math.max(0, level - 1);
    if (item.toolLevels[id] === 0) {
      item.tools = item.tools.filter(toolId => toolId !== id);
    }
  });

  lobbyCredits.textContent = `Credits: ${profile.credits}`;
  showRewardBurst("Item Sold", tool.name);
  renderShopPanel(profile);
}

function getToolPrice(tool, currentLevel = 0) {
  return Math.round(tool.cost * (1 + currentLevel * 0.55));
}

function startGame(mode = "Story", daily = null, multiplayer = "Offline") {
  beginRuntime();
  const profile = getProfile(game.user);
  const mission = daily ? { target: daily.target, level: "EVENT", file: daily.name } : pick(missions);
  const password = generatePassword();
  const cipher = pick(cipherBank);
  const finalToken = generatePassword().toLowerCase().replace(/^a/, "A");
  const countdown = mode === "Speedrun" ? 180 : mode === "Hardcore" ? 210 : mode === "Training" ? 600 : 300;

  Object.assign(game, {
    stage: 1,
    stageTotal: 10,
    puzzleRun: false,
    puzzleIndex: 0,
    mode,
    multiplayer,
    score: 0,
    attempts: 0,
    failedAttempts: 0,
    hints: 0,
    correctActions: 0,
    totalActions: 0,
    startTime: Date.now(),
    countdown,
    hackerId: "",
    codeName: profile.codeName || "",
    difficulty: mode === "Hardcore" ? "Expert" : "Normal",
    firewallAttempts: mode === "Hardcore" ? 2 : 3,
    locked: false,
    commandIndex: 0,
    commandSequence: mode === "Challenge" ? ["scan system", "status", "decrypt", "access", "hack"] : ["scan system", "decrypt", "access", "hack"],
    finalSuccess: false,
    ending: "failure",
    rivalScore: Math.floor(80 + Math.random() * 100),
    mission,
    daily,
    xpEarned: 0,
    creditsEarned: 0,
    combo: 0,
    bestCombo: 0,
    bonusHints: profile.bonusHints,
    password,
    cipher,
    finalToken,
    ports: generatePorts(),
    eventStages: new Set(),
    sessionAchievements: new Set()
  });

  lobbyScreen.classList.remove("active");
  authScreen.classList.remove("active");
  gameScreen.classList.add("active");
  timerId = scheduleInterval(updateHud, 1000);
  countdownId = scheduleInterval(tickCountdown, 1000);
  renderStage(1);
}

function renderStage(stage) {
  game.stage = stage;
  terminalOutput.innerHTML = "";
  interactiveZone.innerHTML = "";
  stageTitle.textContent = `stage-${String(stage).padStart(2, "0")}.${stageNames[stage - 1]}`;
  saveProgress();
  updateHud();

  switch (stage) {
    case 1: renderBootStage(); break;
    case 2: renderPlayerSetup(); break;
    case 3: renderTraining(); break;
    case 4: renderPasswordFirewall(); break;
    case 5: renderEncryption(); break;
    case 6: renderNetworkScan(); break;
    case 7: renderCommandTerminal(); break;
    case 8: renderMultiSecurity(); break;
    case 9: renderFinalHack(); break;
    case 10: renderResults(); break;
  }

  if (stage > 2 && stage < 10) {
    scheduleTimeout(() => maybeRandomEvent(stage), 700);
  }
}

function addLine(text, className = "", typed = false) {
  const node = lineTemplate.content.firstElementChild.cloneNode(true);
  const textNode = node.querySelector(".line-text");
  node.className = `terminal-line ${className}`.trim();
  terminalOutput.appendChild(node);
  terminalOutput.scrollTop = terminalOutput.scrollHeight;

  if (!typed) {
    textNode.textContent = text;
    return;
  }

  let index = 0;
  const interval = scheduleInterval(() => {
    textNode.textContent += text[index] || "";
    index++;
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
    if (index >= text.length) clearInterval(interval);
  }, 12);
}

function typeLines(lines, done) {
  let index = 0;
  const interval = scheduleInterval(() => {
    addLine(lines[index].text, lines[index].className || "", true);
    index++;

    if (index >= lines.length) {
      clearInterval(interval);
      scheduleTimeout(() => done && done(), 350);
    }
  }, 520);
}

function setControls(html) {
  interactiveZone.innerHTML = html;
}

function nextButton(label = "Continue", nextStage = game.stage + 1) {
  setControls(`<button class="primary-button" type="button" id="next-stage">${label}</button>`);
  document.getElementById("next-stage").addEventListener("click", () => advanceToStage(nextStage));
}

function advanceToStage(nextStage) {
  if (nextStage > game.stage && game.stage < 10) {
    rewardStageCompletion(game.stage);
  }
  renderStage(nextStage);
}

function updateHud() {
  const profile = game.user ? getProfile(game.user) : createDefaultProfile("AGENT");
  hudName.textContent = game.codeName || game.user || "AGENT";
  hudId.textContent = `ID: ${game.hackerId || "----"}`;
  hudMode.textContent = `Mode: ${game.mode}${game.multiplayer && game.multiplayer !== "Offline" ? ` / ${game.multiplayer}` : ""}`;
  hudLevel.textContent = `Level ${profile.level}`;
  hudStage.textContent = game.stage;
  hudTotal.textContent = game.stageTotal || 10;
  hudScore.textContent = game.score;
  hudXp.textContent = profile.xp;
  hudCountdown.textContent = game.countdown === null ? "NO LIMIT" : formatTime(Math.max(0, game.countdown));

  if (game.startTime) {
    const seconds = Math.floor((Date.now() - game.startTime) / 1000);
    hudTime.textContent = formatTime(seconds);
  }
}

function tickCountdown() {
  if (game.countdown === null || (!game.puzzleRun && game.stage >= 10) || game.mode === "Training") {
    updateHud();
    return;
  }

  game.countdown--;
  game.rivalScore += Math.floor(Math.random() * 11);
  updateHud();

  if (game.countdown === 30) {
    addLine("Emergency lockdown in 30 seconds.", "warning");
    flashWarning();
  }

  if (game.countdown <= 0) {
    game.finalSuccess = false;
    game.ending = "detected";
    if (game.puzzleRun) {
      renderPuzzleSummary(false);
      return;
    }
    renderStage(10);
  }
}

function award(points) {
  const multiplier = game.mode === "Hardcore" ? 1.25 : game.mode === "Speedrun" ? 1.15 : 1;
  game.combo++;
  game.bestCombo = Math.max(game.bestCombo || 0, game.combo);
  const comboBonus = game.combo >= 3 ? Math.min(60, game.combo * 4) : 0;
  const finalPoints = Math.round((points + comboBonus) * multiplier);
  game.score += finalPoints;
  game.correctActions++;
  game.totalActions++;
  grantXP(Math.max(8, Math.round(points * 0.45)) + comboBonus, comboBonus ? `${game.combo}x combo` : "operation");
  if (points >= 100) grantCredits(Math.round(points * 0.08), "mission payout");
  if (comboBonus) showRewardBurst(`${game.combo}x Combo`, `+${comboBonus} bonus`);
  maybeSurpriseReward();
  aiReact("success");
  updateHud();
}

function miss() {
  game.failedAttempts++;
  game.attempts++;
  game.totalActions++;
  game.combo = 0;
  const stealthReduction = hasTool("stealth") ? 0.5 : 1;
  game.score = Math.max(0, game.score - Math.round((game.mode === "Hardcore" ? 20 : 8) * stealthReduction));
  aiReact("warning");
  updateHud();
  flashWarning();
}

function rewardStageCompletion(stage) {
  const baseXp = 22 + stage * 8;
  const speedBonus = game.countdown > 180 ? 12 : 0;
  grantXP(baseXp + speedBonus, `Stage ${stage} clear`);
  grantCredits(Math.max(4, Math.round(stage * 1.5)), "stage clear");
}

function grantXP(amount, reason = "XP") {
  if (!game.user || amount <= 0) return;
  const profileBefore = getProfile(game.user);
  const multiplier = hasTool("xpMultiplier") ? 1.25 + (getToolLevel("xpMultiplier") * 0.08) : 1;
  const finalAmount = Math.round(amount * multiplier);
  const oldLevel = profileBefore.level;
  const updated = updateProfile(profile => {
    profile.xp += finalAmount;
  });

  game.xpEarned += finalAmount;
  showRewardBurst(`+${finalAmount} XP`, reason);

  if (updated.level > oldLevel) {
    const rewardCredits = 50 + updated.level * 8;
    const reward = updateProfile(profile => {
      profile.credits += rewardCredits;
      if (updated.level % 5 === 0) profile.bonusHints += 1;
      unlockLevelReward(profile, updated.level);
    });
    showRewardBurst("LEVEL UP", `Level ${reward.level}  +${rewardCredits} credits`);
    aiSay(`Level ${reward.level} reached. New black market channels opened.`);
  }

  updateHud();
}

function grantCredits(amount, reason = "credits") {
  if (!game.user || amount <= 0) return;
  const updated = updateProfile(profile => {
    profile.credits += amount;
  });
  game.creditsEarned += amount;
  lobbyCredits.textContent = `Credits: ${updated.credits}`;
  showRewardBurst(`+${amount} credits`, reason);
}

function unlockLevelReward(profile, level) {
  const rewardTool = tools.find(tool => tool.unlockLevel === level && !profile.tools.includes(tool.id));
  if (!rewardTool) return;
  profile.tools.push(rewardTool.id);
  profile.toolLevels[rewardTool.id] = 1;
  showRewardBurst("Tool Unlocked", rewardTool.name);
}

function maybeSurpriseReward() {
  if (Math.random() > 0.08) return;
  const xp = 15 + Math.floor(Math.random() * 25);
  const credits = 6 + Math.floor(Math.random() * 15);
  updateProfile(profile => {
    profile.xp += xp;
    profile.credits += credits;
  });
  game.xpEarned += xp;
  game.creditsEarned += credits;
  showRewardBurst("Surprise Cache", `+${xp} XP  +${credits} credits`);
}

function startModeRun(modeName) {
  const config = modeConfigs[modeName] || modeConfigs["Core Breach"];
  beginPuzzleRun({
    modeName,
    games: config.games,
    timeLimit: config.timeLimit,
    loop: config.loop,
    randomOrder: config.randomOrder,
    practiceOnly: false,
    startIndex: 0
  });
}

function startPuzzleLab(options = {}) {
  const {
    games = puzzleStages.map(puzzle => puzzle.id),
    timeLimit = 300,
    startIndex = 0,
    practiceOnly = false,
    modeName = practiceOnly ? "Puzzle Practice" : "Puzzle Lab"
  } = options;

  beginPuzzleRun({
    modeName,
    games: practiceOnly ? ["memory"] : games,
    timeLimit: practiceOnly ? 120 : timeLimit,
    loop: false,
    practiceOnly,
    startIndex
  });
}

function beginPuzzleRun({ modeName, games, timeLimit, loop, randomOrder = false, practiceOnly, startIndex }) {
  beginRuntime();
  const profile = getProfile(game.user);
  const safeStartIndex = Number.isInteger(startIndex) ? startIndex : 0;
  const baseSequence = Array.isArray(games) && games.length ? games : modeConfigs["Core Breach"].games;
  const sequence = randomOrder ? shuffleList(baseSequence) : [...baseSequence];

  Object.assign(game, {
    stage: 1,
    stageTotal: sequence.length,
    puzzleRun: true,
    puzzlePractice: practiceOnly,
    puzzleSequence: sequence,
    modeConfig: { loop, timeLimit },
    usedExamples: {},
    puzzleIndex: safeStartIndex,
    mode: modeName,
    score: 0,
    attempts: 0,
    failedAttempts: 0,
    hints: 0,
    correctActions: 0,
    totalActions: 0,
    combo: 0,
    bestCombo: 0,
    xpEarned: 0,
    creditsEarned: 0,
    rivalScore: 0,
    startTime: Date.now(),
    countdown: timeLimit,
    codeName: profile.codeName || profile.username,
    hackerId: `PX-${Math.floor(1000 + Math.random() * 9000)}`,
    finalSuccess: false,
    ending: "failure",
    eventStages: new Set(),
    sessionAchievements: new Set()
  });

  lobbyScreen.classList.remove("active");
  authScreen.classList.remove("active");
  gameScreen.classList.add("active");
  timerId = scheduleInterval(updateHud, 1000);
  countdownId = scheduleInterval(tickCountdown, 1000);
  renderPuzzleStage(safeStartIndex);
}

function renderPuzzleStage(index) {
  const activeStages = getActivePuzzleStages();
  const safeIndex = Number.isInteger(index) && activeStages[index] ? index : 0;
  const puzzle = activeStages[safeIndex];
  game.puzzleIndex = safeIndex;
  game.stage = game.puzzlePractice ? 1 : safeIndex + 1;
  terminalOutput.innerHTML = "";
  interactiveZone.innerHTML = "";
  stageTitle.textContent = `puzzle-${String(safeIndex + 1).padStart(2, "0")}.${puzzle.id}`;
  updateHud();

  addLine(`Puzzle loaded: ${puzzle.name}`, "ai", true);
  addLine(puzzle.desc, "", true);

  const renderers = {
    memory: renderMemoryPuzzle,
    guess: renderGuessNumberPuzzle,
    caesar: renderCaesarCipherPuzzle,
    vigenere: renderVigenereCipherPuzzle,
    ports: renderPortSelectPuzzle,
    prompt: renderPromptPuzzle,
    reverse: renderReverseCipherPuzzle,
    ascii: renderAsciiConversionPuzzle,
    hex: renderHexadecimalConversionPuzzle,
    ip: renderIpTrackerPuzzle,
    base64: renderBase64Puzzle,
    binary: renderBinaryPuzzle,
    morse: renderMorsePuzzle,
    debug: renderDebugPuzzle,
    "password-profile": renderPasswordProfilePuzzle,
    logic: renderLogicGatePuzzle,
    pattern: renderPatternPuzzle,
    speed: renderSpeedTypingPuzzle
  };

  scheduleTimeout(() => renderers[puzzle.id](), 650);
}

function getActivePuzzleStages() {
  const ids = game.puzzleSequence && game.puzzleSequence.length ? game.puzzleSequence : puzzleStages.map(puzzle => puzzle.id);
  return ids.map(id => puzzleStages.find(puzzle => puzzle.id === id)).filter(Boolean);
}

function completePuzzle(success, points, message) {
  if (success) {
    addLine(message || "Puzzle solved.", "success");
    award(points);
  } else {
    addLine(message || "Puzzle failed.", "warning");
    miss();
  }

  const activeStages = getActivePuzzleStages();
  const isLast = !game.modeConfig?.loop && (game.puzzlePractice || game.puzzleIndex >= activeStages.length - 1);
  setControls(`
    <div class="status-strip">
      <span class="status-pill">${success ? "SUCCESS" : "FAILED"}</span>
      <span class="status-pill">Score: ${game.score}</span>
      <span class="status-pill">Combo: ${game.combo}</span>
    </div>
    <button class="primary-button" id="puzzle-next" type="button">${isLast ? "View Puzzle Results" : "Next Puzzle"}</button>
  `);
  document.getElementById("puzzle-next").addEventListener("click", () => {
    if (isLast) {
      renderPuzzleSummary(success);
    } else {
      rewardStageCompletion(game.stage);
      const nextIndex = game.modeConfig?.loop && game.puzzleIndex >= activeStages.length - 1 ? 0 : game.puzzleIndex + 1;
      renderPuzzleStage(nextIndex);
    }
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));
}

function puzzleInputControls(placeholder, buttonLabel, onSubmit, extra = "") {
  setControls(`
    ${extra}
    <div class="command-input-row">
      <input id="puzzle-answer" type="text" placeholder="${placeholder}">
      <button class="primary-button" id="puzzle-submit" type="button">${buttonLabel}</button>
    </div>
  `);
  const input = document.getElementById("puzzle-answer");
  const submit = () => onSubmit(input.value.trim());
  document.getElementById("puzzle-submit").addEventListener("click", submit);
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") submit();
  });
  input.focus();
}

function pickModeExample(pool, key) {
  if (!Array.isArray(pool) || pool.length === 0) return null;
  if (!game.usedExamples[key]) game.usedExamples[key] = [];

  if (game.usedExamples[key].length >= pool.length) {
    game.usedExamples[key] = [];
  }

  let index = Math.floor(Math.random() * pool.length);
  while (game.usedExamples[key].includes(index) && game.usedExamples[key].length < pool.length) {
    index = Math.floor(Math.random() * pool.length);
  }

  game.usedExamples[key].push(index);
  return pool[index];
}

function renderMemoryPuzzle() {
  const sequence = pickModeExample(memoryExamples, "memory");
  setControls(`
    <div class="combo-stream" id="memory-sequence">MEMORIZE: ${sequence}</div>
    <div class="progress"><span id="memory-progress" style="--value: 0%;"></span></div>
  `);
  animateProgress("memory-progress", 100);
  scheduleTimeout(() => {
    puzzleInputControls("enter remembered sequence", "Submit Memory", answer => {
      completePuzzle(answer === sequence, 95, `Memory sequence ${answer === sequence ? "matched" : "mismatch"}.`);
    }, `<div class="combo-stream">SEQUENCE HIDDEN</div>`);
  }, 2200);
}

function renderCaesarCipherPuzzle() {
  const item = pickModeExample(caesarExamples, "caesar");
  addLine(`Caesar encrypted text: ${item.encrypted}`);
  addLine(item.hint, "ai");
  puzzleInputControls("decoded answer", "Decode Caesar", answer => {
    completePuzzle(answer.toUpperCase() === item.answer, 100, answer.toUpperCase() === item.answer ? "Caesar cipher decoded." : `Caesar failed. Answer was ${item.answer}.`);
  });
}

function renderVigenereCipherPuzzle() {
  const item = pickModeExample(vigenereExamples, "vigenere");
  addLine(`Vigenere encrypted text: ${item.encrypted}`);
  addLine(item.hint, "ai");
  puzzleInputControls("decoded answer", "Decode Vigenere", answer => {
    completePuzzle(answer.toUpperCase() === item.answer, 110, answer.toUpperCase() === item.answer ? "Vigenere cipher decoded." : `Vigenere failed. Answer was ${item.answer}.`);
  });
}

function renderPortSelectPuzzle() {
  const ports = generatePorts();
  addLine("Select one OPEN port from the scan.");
  setControls(`<div class="port-grid" id="mode-port-grid"></div>`);
  const grid = document.getElementById("mode-port-grid");
  ports.forEach((item, index) => {
    scheduleTimeout(() => {
      const button = document.createElement("button");
      button.className = `port-button ${item.open ? "open" : item.state.toLowerCase()}`;
      button.type = "button";
      button.innerHTML = `<strong>PORT ${item.port}</strong>${item.state}`;
      button.addEventListener("click", () => {
        game.attempts++;
        game.totalActions++;
        completePuzzle(item.open, item.open ? 100 : 0, item.open ? "Safe port selected." : "Wrong port selected. Alert raised.");
      });
      grid.appendChild(button);
    }, index * 180);
  });
}

function renderPromptPuzzle() {
  const sequence = ["scan system", "decrypt", "access", "hack"];
  let index = 0;
  addLine(`Prompt sequence: ${sequence.join(" -> ")}`);
  puzzleInputControls("type next command", "Run Command", answer => {
    const value = answer.toLowerCase();
    addLine(`$ ${value}`);
    if (value === sequence[index]) {
      index++;
      if (index >= sequence.length) {
        completePuzzle(true, 120, "Prompt sequence completed.");
      } else {
        addLine(`Accepted. Next command: ${sequence[index]}`, "success");
        const input = document.getElementById("puzzle-answer");
        if (input) input.value = "";
      }
    } else {
      completePuzzle(false, 0, `Prompt failed. Expected ${sequence[index]}.`);
    }
  }, `<div class="status-strip"><span class="status-pill">Commands: ${sequence.length}</span></div>`);
}

function renderGuessNumberPuzzle() {
  const secret = Math.floor(1 + Math.random() * 20);
  let attemptsLeft = 5;
  puzzleInputControls("guess 1-20", "Guess", answer => {
    const guess = Number(answer);
    game.attempts++;
    game.totalActions++;
    if (guess === secret) {
      completePuzzle(true, 80, "Number lock cracked.");
      return;
    }
    attemptsLeft--;
    addLine(guess > secret ? "Too high." : "Too low.", "ai");
    if (attemptsLeft <= 0) completePuzzle(false, 0, `Number lock failed. Code was ${secret}.`);
  }, `<div class="status-strip"><span class="status-pill">Attempts: 5</span><span class="status-pill">Range: 1-20</span></div>`);
}

function renderReverseCipherPuzzle() {
  const item = pickModeExample(hardReverseExamples, "reverse");
  addLine(`Encrypted payload: ${item.encrypted}`);
  puzzleInputControls("decoded word", "Decode", answer => {
    completePuzzle(answer === item.answer, 90, answer === item.answer ? "Reverse cipher decoded." : `Reverse cipher failed. Answer was ${item.answer}.`);
  });
}

function renderAsciiConversionPuzzle() {
  const item = pickModeExample(asciiConversionExamples, "ascii");
  addLine(`ASCII sequence: ${item.encrypted}`);
  puzzleInputControls("decoded word", "Decode ASCII", answer => {
    const correct = answer.toUpperCase() === item.answer;
    completePuzzle(correct, 105, correct ? "ASCII conversion accepted." : `ASCII conversion failed. Answer was ${item.answer}.`);
  });
}

function renderHexadecimalConversionPuzzle() {
  const item = pickModeExample(hexadecimalConversionExamples, "hex");
  addLine(`Hexadecimal sequence: ${item.encrypted}`);
  puzzleInputControls("decoded word", "Decode Hex", answer => {
    const correct = answer.toUpperCase() === item.answer;
    completePuzzle(correct, 105, correct ? "Hexadecimal conversion accepted." : `Hexadecimal conversion failed. Answer was ${item.answer}.`);
  });
}

function renderIpTrackerPuzzle() {
  const item = pickModeExample(ipTrackerExamples, "ip");
  addLine(`Binary IP packet: ${item.encrypted}`);
  puzzleInputControls("dotted decimal IP", "Track IP", answer => {
    const correct = answer.replace(/\s+/g, "") === item.answer;
    completePuzzle(correct, 110, correct ? "IP tracker matched." : `IP tracker failed. Answer was ${item.answer}.`);
  });
}

function renderBase64Puzzle() {
  const item = pickModeExample(base64Examples, "base64");
  addLine(`Base64 payload: ${item.encrypted}`);
  puzzleInputControls("decoded word", "Decode Base64", answer => {
    const correct = answer.toUpperCase() === item.answer;
    completePuzzle(correct, 105, correct ? "Base64 payload decoded." : `Base64 decode failed. Answer was ${item.answer}.`);
  });
}

function renderBinaryPuzzle() {
  const item = pickModeExample(binaryExamples, "binary");
  addLine(`Binary stream: ${item.encrypted}`);
  puzzleInputControls("translated text", "Translate", answer => {
    completePuzzle(answer.toUpperCase() === item.answer, 95, answer.toUpperCase() === item.answer ? "Binary translation accepted." : `Binary translation failed. Answer was ${item.answer}.`);
  });
}

function renderMorsePuzzle() {
  const item = pickModeExample(morseExamples, "morse");
  addLine(`Morse transmission: ${item.encrypted}`);
  puzzleInputControls("decoded message", "Decode Morse", answer => {
    completePuzzle(answer.toUpperCase() === item.answer, 100, answer.toUpperCase() === item.answer ? "Morse signal decoded." : `Morse decode failed. Answer was ${item.answer}.`);
  });
}

function renderDebugPuzzle() {
  const item = pickModeExample(debugExamples, "debug");
  addLine(`Debug task: ${item.title}`);
  addLine("Enter only the line number where the issue exists.", "ai");
  puzzleInputControls("error line number", "Submit Line", answer => {
    const correct = answer.replace(/\s+/g, "") === item.answer;
    completePuzzle(correct, 120, correct ? "Bug line identified." : `Debug failed. Error line was ${item.answer}.`);
  }, `<pre class="code-card">${escapeHtml(item.code)}</pre>`);
}

function renderPasswordProfilePuzzle() {
  const item = pickModeExample(passwordProfileExamples, "password-profile");
  let attemptsLeft = 5;

  addLine(`Password profile: ${item.title}`);
  addLine("Guess the likely password from the captured profile.", "ai");
  puzzleInputControls("password guess", "Submit Guess", answer => {
    if (answer === item.answer) {
      completePuzzle(true, 130, "Password profile cracked.");
      return;
    }

    attemptsLeft--;
    if (attemptsLeft <= 0) {
      completePuzzle(false, 0, `Password profiling failed. Answer was ${item.answer}.`);
      return;
    }

    game.attempts++;
    game.failedAttempts++;
    game.totalActions++;
    game.combo = 0;
    addLine(`Wrong password. Attempts left: ${attemptsLeft}`, "warning");

    const attempts = document.getElementById("profile-attempts-left");
    if (attempts) attempts.textContent = attemptsLeft;

    const input = document.getElementById("puzzle-answer");
    if (input) {
      input.value = "";
      input.focus();
    }

    updateHud();
    flashWarning();
  }, `
    <pre class="code-card">${escapeHtml(item.info)}</pre>
    <div class="status-strip"><span class="status-pill">Attempts left: <strong id="profile-attempts-left">5</strong></span></div>
  `);
}

function renderLogicGatePuzzle() {
  const item = pickModeExample(logicGateExamples, "logic");
  addLine(`Logic gate: ${item.a} ${item.gate} ${item.b}`);
  puzzleInputControls("output 0 or 1", "Submit Output", answer => {
    completePuzzle(answer === item.answer, 90, answer === item.answer ? "Logic gate bypassed." : `Logic gate failed. Output was ${item.answer}.`);
  });
}

function renderPatternPuzzle() {
  const item = pickModeExample(patternExamples, "pattern");
  addLine(`Security pattern: ${item.prompt}`);
  puzzleInputControls("next value", "Predict", answer => {
    completePuzzle(answer.toUpperCase() === item.answer, 95, answer.toUpperCase() === item.answer ? "Pattern prediction accepted." : `Pattern prediction failed. Answer was ${item.answer}.`);
  });
}

function renderSpeedTypingPuzzle() {
  const item = pickModeExample(speedTypingExamples, "speed");
  const phrase = item.phrase;
  let timeLeft = item.seconds;
  let completed = false;

  puzzleInputControls("type phrase exactly", "Execute", answer => {
    if (completed) return;
    completed = true;
    clearInterval(speedTimer);
    completePuzzle(answer.toUpperCase() === phrase, 120, answer.toUpperCase() === phrase ? "Speed command executed." : "Speed typing mismatch.");
  }, `
    <div class="status-strip">
      <span class="status-pill">Phrase: <strong>${phrase}</strong></span>
      <span class="status-pill">Time: <strong id="speed-time">${item.seconds}</strong>s</span>
    </div>
  `);

  const speedTimer = scheduleInterval(() => {
    timeLeft--;
    const timer = document.getElementById("speed-time");
    if (timer) timer.textContent = timeLeft;
    if (timeLeft <= 0 && !completed) {
      completed = true;
      clearInterval(speedTimer);
      completePuzzle(false, 0, "Speed typing timer expired.");
    }
  }, 1000);
}

function renderPuzzleSummary(success) {
  clearTimers();
  game.finalSuccess = game.failedAttempts <= 3 || success;
  const elapsed = Math.max(1, Math.floor((Date.now() - game.startTime) / 1000));
  const accuracy = game.totalActions === 0 ? 100 : Math.round((game.correctActions / game.totalActions) * 100);
  const bonus = Math.max(0, game.countdown);
  game.score += game.finalSuccess ? Math.round(bonus / 2) : 0;
  grantXP(game.finalSuccess ? 160 : 45, "Puzzle Lab result");
  grantCredits(game.finalSuccess ? 60 : 15, "Puzzle Lab payout");
  updateProfile(profile => {
    profile.lastScore = game.score;
    profile.bestScore = Math.max(profile.bestScore, game.score);
    profile.accuracy = accuracy;
    profile.performance.totalRuns++;
    if (game.finalSuccess) profile.performance.totalWins++;
    profile.performance.bestAccuracy = Math.max(profile.performance.bestAccuracy, accuracy);
    profile.performance.bestCombo = Math.max(profile.performance.bestCombo, game.bestCombo || game.combo);
    if (game.finalSuccess) {
      profile.performance.fastestWin = profile.performance.fastestWin === null
        ? elapsed
        : Math.min(profile.performance.fastestWin, elapsed);
    }
    profile.matchHistory.unshift({
      mode: game.mode,
      score: game.score,
      rank: profile.rank,
      result: game.finalSuccess ? "win" : "loss",
      accuracy,
      attempts: game.attempts,
      time: elapsed,
      xp: game.xpEarned,
      credits: game.creditsEarned
    });
    profile.matchHistory = profile.matchHistory.slice(0, 5);
  });

  terminalOutput.innerHTML = "";
  stageTitle.textContent = "puzzle-results.summary";
  addLine(game.finalSuccess ? "Puzzle Lab completed." : "Puzzle Lab finished with failures.", game.finalSuccess ? "success" : "warning");
  addLine(`Accuracy: ${accuracy}% | Time: ${formatTime(elapsed)} | Score: ${game.score}`);
  setControls(`
    <div class="result-grid">
      <div class="result-card"><strong>Score</strong>${game.score}</div>
      <div class="result-card"><strong>XP Earned</strong>${game.xpEarned}</div>
      <div class="result-card"><strong>Credits Earned</strong>${game.creditsEarned}</div>
      <div class="result-card"><strong>Attempts</strong>${game.attempts}</div>
      <div class="result-card"><strong>Accuracy</strong>${accuracy}%</div>
      <div class="result-card"><strong>Time</strong>${formatTime(elapsed)}</div>
    </div>
    <div class="control-grid" style="margin-top: 16px;">
      <button class="primary-button" id="retry-puzzles" type="button">Run Puzzle Lab Again</button>
      <button class="ghost-button" id="exit-puzzles" type="button">Exit To Lobby</button>
    </div>
  `);
  document.getElementById("retry-puzzles").addEventListener("click", () => {
    if (modeConfigs[game.mode]) {
      startModeRun(game.mode);
      return;
    }

    startPuzzleLab({
      games: [...(game.puzzleSequence || puzzleStages.map(puzzle => puzzle.id))],
      timeLimit: game.modeConfig ? game.modeConfig.timeLimit : 300
    });
  });
  document.getElementById("exit-puzzles").addEventListener("click", () => returnToMainMenu(false));
}

function renderBootStage() {
  typeLines([
    { text: "Booting CYBERDECK-OS v7.4..." },
    { text: "Loading stealth modules: decryptor, scanner, bypass, trace-mask" },
    { text: "Connecting to darknet relay: LOCALHOST:3000" },
    { text: `Target: ${game.mission.target}` },
    { text: `Security Level: ${game.mission.level}` },
    { text: "Verifying operator signature..." },
    { text: "Terminal access granted.", className: "success" }
  ], () => {
    setControls(`
      <div class="progress"><span id="boot-progress" style="--value: 0%;"></span></div>
      <button class="primary-button" type="button" id="next-stage">Enter Setup</button>
    `);
    animateProgress("boot-progress", 100);
    document.getElementById("next-stage").addEventListener("click", () => advanceToStage(2));
  });
}

function renderPlayerSetup() {
  addLine(`Mission assignment: extract classified file ${game.mission.file}.`, "ai", true);
  addLine("Create your profile before connecting.", "", true);

  setControls(`
    <div class="form-row">
      <div>
        <label for="codename">Code name</label>
        <input id="codename" type="text" placeholder="ShadowByte" maxlength="18" value="${game.codeName}">
      </div>
      <div>
        <label for="difficulty">Difficulty</label>
        <select id="difficulty">
          <option ${game.difficulty === "Normal" ? "selected" : ""}>Normal</option>
          <option ${game.difficulty === "Hard" ? "selected" : ""}>Hard</option>
          <option ${game.difficulty === "Expert" ? "selected" : ""}>Expert</option>
        </select>
      </div>
      <button class="primary-button" id="create-profile" type="button">Generate Profile</button>
    </div>
  `);

  document.getElementById("create-profile").addEventListener("click", () => {
    game.codeName = document.getElementById("codename").value.trim() || "GhostRoot";
    game.difficulty = document.getElementById("difficulty").value;
    game.hackerId = `HX-${Math.floor(1000 + Math.random() * 9000)}`;
    updateProfile(profile => {
      profile.codeName = game.codeName;
    });
    award(50);
    addLine(`Hacker ID generated: ${game.hackerId}`, "success");
    addLine(`Welcome ${game.codeName}. Difficulty set to ${game.difficulty}.`, "success");
    nextButton(game.mode === "Training" ? "Begin Tutorial" : "Start Training");
  });
}

function renderTraining() {
  const sequence = game.mode === "Training" ? ["help", "scan", "status", "decrypt"] : ["help", "scan", "decrypt"];
  addLine("AI ASSISTANT: Welcome Agent.", "ai");
  addLine("Type HELP to begin. Then scan the network and decrypt the practice file.", "ai");
  addLine("Available commands: help, scan, access, decrypt, status");
  renderSimpleCommandPuzzle(sequence, "Training completed. Excellent work.", 75, 4);
}

function renderSimpleCommandPuzzle(sequence, successText, points, nextStage) {
  let index = 0;
  setControls(`
    <div class="status-strip">
      <span class="status-pill">Required: ${sequence.join(" -> ")}</span>
      <span class="status-pill">AI hints: ${game.mode === "Training" ? "enabled" : "limited"}</span>
    </div>
    <div class="command-input-row">
      <input id="command-input" type="text" placeholder="type command">
      <button class="primary-button" id="run-command" type="button">Execute</button>
    </div>
  `);

  const input = document.getElementById("command-input");
  const run = () => {
    const value = input.value.trim().toLowerCase();
    if (!value) return;
    addLine(`$ ${value}`);
    addLine("Processing command...", "ai");

    scheduleTimeout(() => {
      if (value === sequence[index]) {
        addLine(`Command accepted: ${value}`, "success");
        index++;
        award(15);
        if (index === sequence.length) {
          addLine(successText, "success");
          award(points);
          nextButton("Continue", nextStage);
        }
      } else {
        addLine(`Invalid command. Expected: ${sequence[index]}`, "warning");
        miss();
      }
    }, 320);
    input.value = "";
    input.focus();
  };

  document.getElementById("run-command").addEventListener("click", run);
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") run();
  });
}

function renderPasswordFirewall() {
  game.firewallAttempts = game.mode === "Hardcore" ? 2 : 3;
  game.locked = false;
  addLine("Password Firewall detected.", "warning");
  addLine("Rules: length = 5, starts with 'A', contains a number.");
  addLine(`Recovered partial pattern: ${game.password[0]}***${game.password[4]}`, "ai");
  if (hasTool("analyzer")) {
    addLine(`Password Analyzer: likely key is ${game.password.slice(0, 2)}**${game.password[4]}.`, "ai");
  }
  drawFirewallControls();
}

function drawFirewallControls() {
  setControls(`
    <div class="status-strip">
      <span class="status-pill">Attempts left: <strong id="attempts-left">${game.firewallAttempts}</strong></span>
      <span class="status-pill">Hints used: <strong id="hint-count">${game.hints}</strong></span>
      <span class="status-pill">Tool: ${hasTool("bypass") ? "Firewall Bypass ready" : "Manual bypass"}</span>
    </div>
    <div class="mode-grid firewall-choice">
      <div class="mode-card active-mode">
        <h3>Manual Password Crack</h3>
        <p>Read the rules and enter the password yourself. Higher score, higher risk.</p>
        <button class="mode-button" id="manual-mode" type="button">Manual Crack</button>
      </div>
      <div class="mode-card">
        <h3>Simulated Brute Force</h3>
        <p>Educational auto-crack simulation. Lower score, easier access.${hasTool("bruteforce") ? " Tool boost active." : ""}</p>
        <button class="mode-button" id="bruteforce-mode" type="button">Brute Force Attack</button>
      </div>
    </div>
    <div id="manual-crack-panel" class="command-input-row">
      <input id="firewall-password" type="text" maxlength="12" placeholder="enter password">
      <button class="primary-button" id="check-password" type="button">Bypass</button>
    </div>
    <div id="bruteforce-panel" class="bruteforce-panel hidden">
      <div class="progress"><span id="bruteforce-progress" style="--value: 0%;"></span></div>
      <div class="crack-readout">
        <span>Cracking speed: <strong id="crack-speed">0 keys/sec</strong></span>
        <span>Attempts: <strong id="crack-attempts">0</strong></span>
        <span>Status: <strong id="crack-status">idle</strong></span>
      </div>
      <div id="combo-stream" class="combo-stream">Awaiting attack command...</div>
      <button class="primary-button" id="start-bruteforce" type="button">Start Simulated Attack</button>
    </div>
    <div class="control-grid">
      <button class="ghost-button" id="hint-password" type="button">Hint</button>
      <button class="ghost-button" id="tool-password" type="button">Use Tool</button>
      <button class="ghost-button" id="retry-password" type="button">Retry</button>
      <button class="ghost-button" id="quit-game" type="button">Quit</button>
    </div>
  `);

  document.getElementById("manual-mode").addEventListener("click", () => setFirewallMode("manual"));
  document.getElementById("bruteforce-mode").addEventListener("click", () => setFirewallMode("bruteforce"));
  document.getElementById("check-password").addEventListener("click", checkFirewallPassword);
  document.getElementById("start-bruteforce").addEventListener("click", startBruteForceSimulation);
  document.getElementById("hint-password").addEventListener("click", () => useHint(`Hint: the generated key is ${game.password}.`));
  document.getElementById("tool-password").addEventListener("click", () => {
    if (!hasTool("bypass")) {
      addLine("Firewall Bypass tool is locked. Earn a higher score to unlock it.", "warning");
      return;
    }
    document.getElementById("firewall-password").value = game.password;
    addLine("Firewall Bypass injected the recovered password.", "success");
  });
  document.getElementById("retry-password").addEventListener("click", () => renderPasswordFirewall());
  document.getElementById("quit-game").addEventListener("click", () => {
    game.finalSuccess = false;
    game.ending = "failure";
    renderStage(10);
  });
}

function setFirewallMode(mode) {
  const manualPanel = document.getElementById("manual-crack-panel");
  const brutePanel = document.getElementById("bruteforce-panel");
  const manualButton = document.getElementById("manual-mode");
  const bruteButton = document.getElementById("bruteforce-mode");

  manualPanel.classList.toggle("hidden", mode !== "manual");
  brutePanel.classList.toggle("hidden", mode !== "bruteforce");
  manualButton.closest(".mode-card").classList.toggle("active-mode", mode === "manual");
  bruteButton.closest(".mode-card").classList.toggle("active-mode", mode === "bruteforce");
}

function checkFirewallPassword() {
  if (game.locked) return;
  const value = document.getElementById("firewall-password").value.trim();
  game.attempts++;
  game.totalActions++;

  if (isValidFirewallPassword(value)) {
    addLine("Firewall password accepted.", "success");
    unlockAchievement("firewall");
    award(120);
    nextButton("Open Encryption Challenge", 5);
    return;
  }

  game.firewallAttempts--;
  game.failedAttempts++;
  addLine("Password rejected.", "warning");
  flashWarning();
  document.getElementById("attempts-left").textContent = game.firewallAttempts;

  if (game.firewallAttempts <= 0) {
    game.locked = true;
    game.ending = "detected";
    addLine("System locked. Retry or quit.", "warning");
  }
}

function startBruteForceSimulation() {
  if (game.locked) return;

  const startButton = document.getElementById("start-bruteforce");
  const progress = document.getElementById("bruteforce-progress");
  const stream = document.getElementById("combo-stream");
  const speed = document.getElementById("crack-speed");
  const attempts = document.getElementById("crack-attempts");
  const status = document.getElementById("crack-status");
  const simulatedAttempts = buildBruteForceAttempts();
  let index = 0;

  startButton.disabled = true;
  status.textContent = "running";
  stream.textContent = "";
  addLine("Launching simulated brute force module.", "ai");
  addLine("Educational sandbox active: no real systems are targeted.", "ai");

  const interval = scheduleInterval(() => {
    const combo = simulatedAttempts[index];
    const currentAttempt = index + 1;
    const percent = Math.round((currentAttempt / simulatedAttempts.length) * 100);

    stream.textContent = `Trying: ${combo}`;
    speed.textContent = `${900 + currentAttempt * 37} keys/sec`;
    attempts.textContent = currentAttempt;
    progress.style.setProperty("--value", `${percent}%`);

    if (currentAttempt % 4 === 0) {
      addLine(`Trying: ${combo}`);
    }

    index++;

    if (index >= simulatedAttempts.length) {
      clearInterval(interval);
      completeBruteForce(simulatedAttempts.length);
    }
  }, 90);
}

function buildBruteForceAttempts() {
  const attempts = [];
  const maxAttempts = hasTool("bruteforce") ? Math.max(8, 18 - getToolLevel("bruteforce") * 3) : 18;

  for (let number = 1; number <= maxAttempts; number++) {
    attempts.push(`A${String(number).padStart(4, "0")}`);
  }

  attempts.push(game.password);
  return attempts;
}

function completeBruteForce(simulatedAttemptCount) {
  const status = document.getElementById("crack-status");
  const stream = document.getElementById("combo-stream");

  game.attempts += simulatedAttemptCount;
  game.totalActions++;
  status.textContent = "cracked";
  stream.innerHTML = `<strong class="access-granted">ACCESS GRANTED</strong><br>Recovered key: ${game.password}`;
  addLine(`Recovered firewall key: ${game.password}`, "success");
  addLine("ACCESS GRANTED", "success");
  flashWarning();
  unlockAchievement("firewall");
  award(hasTool("bruteforce") ? 75 : 55);
  if (hasTool("bruteforce")) grantXP(25 + getToolLevel("bruteforce") * 8, "Brute Force Tool");

  scheduleTimeout(() => {
    nextButton("Open Encryption Challenge", 5);
  }, 900);
}

function renderEncryption() {
  addLine("Encryption Challenge loaded.");
  addLine(`Cipher type detected: ${game.cipher.type}.`);
  addLine(`Encrypted message: ${game.cipher.encrypted}`);
  addLine(game.cipher.hint, "ai");

  setControls(`
    <div class="progress"><span id="decrypt-progress" style="--value: 0%;"></span></div>
    <div class="command-input-row">
      <input id="cipher-answer" type="text" placeholder="decoded message">
      <button class="primary-button" id="submit-cipher" type="button">Validate</button>
    </div>
    <div class="control-grid">
      <button class="ghost-button" id="cipher-hint" type="button">Use Hint</button>
      <button class="ghost-button" id="decryptor-tool" type="button">Use Decryptor</button>
    </div>
  `);
  animateProgress("decrypt-progress", 67);

  document.getElementById("submit-cipher").addEventListener("click", checkCipher);
  document.getElementById("cipher-hint").addEventListener("click", () => useHint(`Decoded answer format: ${game.cipher.answer.length} letters.`));
  document.getElementById("decryptor-tool").addEventListener("click", () => {
    if (!hasTool("decryptor") && !hasTool("aiDecryptor") && !hasTool("quantum")) return;
    document.getElementById("cipher-answer").value = game.cipher.answer;
    animateProgress("decrypt-progress", 100);
    addLine(hasTool("quantum") ? "Quantum Decoder restored the encrypted payload." : "Decryptor filled a probable answer.", "success");
    if (hasTool("aiDecryptor") || hasTool("quantum")) grantXP(20 + getToolLevel("aiDecryptor") * 6, "decrypt booster");
  });
}

function checkCipher() {
  const answer = document.getElementById("cipher-answer").value.trim().toUpperCase();
  game.attempts++;
  game.totalActions++;
  if (answer === game.cipher.answer) {
    addLine(`Decryption success: ${game.cipher.answer}`, "success");
    unlockAchievement("cipher");
    award(130);
    nextButton("Scan Network", 6);
  } else {
    game.failedAttempts++;
    addLine("Decryption failed. Try again.", "warning");
    flashWarning();
  }
}

function renderNetworkScan() {
  addLine("Network scan initiated. Ports will appear as packets return.");
  if (hasTool("scanner")) {
    addLine("Advanced Port Scanner active: OPEN ports will pulse brighter.", "ai");
  }
  setControls(`<div id="scan-progress" class="progress"><span style="--value: 0%;"></span></div><div class="port-grid" id="port-grid"></div>`);
  const grid = document.getElementById("port-grid");
  const progress = document.querySelector("#scan-progress span");

  game.ports.forEach((item, index) => {
    scheduleTimeout(() => {
      progress.style.setProperty("--value", `${Math.round(((index + 1) / game.ports.length) * 100)}%`);
      const button = document.createElement("button");
      button.className = `port-button ${item.open ? "open" : item.state.toLowerCase()}`;
      button.type = "button";
      button.dataset.open = String(item.open);
      button.innerHTML = `<strong>PORT ${item.port}</strong>${item.state}`;
      button.style.animationDelay = `${index * 80}ms`;
      button.addEventListener("click", () => selectPort(button, item));
      grid.appendChild(button);
    }, index * 420);
  });
}

function selectPort(button, item) {
  game.attempts++;
  game.totalActions++;

  if (item.open) {
    addLine(`${button.textContent.trim()} selected. Tunnel established.`, "success");
    award(120);
    nextButton("Open Command Terminal", 7);
  } else {
    game.failedAttempts++;
    addLine(`${button.textContent.trim()} selected. Access denied. Alert raised.`, "warning");
    flashWarning();
  }
}

function renderCommandTerminal() {
  game.commandIndex = 0;
  addLine("Command terminal unlocked.");
  addLine("Commands: help, scan system, decrypt, access, status, hack, disconnect");
  addLine(`Required sequence: ${game.commandSequence.join(" -> ")}`);

  setControls(`
    <div class="status-strip">
      <span class="status-pill">Rival score: <strong id="rival-score">${game.rivalScore}</strong></span>
      <span class="status-pill">Command history enabled</span>
    </div>
    <div class="command-grid">
      ${["help", "scan system", "decrypt", "access", "status", "hack", "disconnect"].map(command =>
        `<button class="command-chip" type="button" data-command="${command}">${command}</button>`
      ).join("")}
    </div>
    <div class="command-input-row" style="margin-top: 14px;">
      <input id="manual-command" type="text" placeholder="or type command">
      <button class="primary-button" id="manual-execute" type="button">Execute</button>
    </div>
  `);

  document.querySelectorAll(".command-chip").forEach(button => {
    button.addEventListener("click", () => runStageSevenCommand(button.dataset.command));
  });
  document.getElementById("manual-execute").addEventListener("click", submitManualCommand);
  document.getElementById("manual-command").addEventListener("keydown", event => {
    if (event.key === "Enter") submitManualCommand();
  });
}

function submitManualCommand() {
  const input = document.getElementById("manual-command");
  runStageSevenCommand(input.value.trim().toLowerCase());
  input.value = "";
}

function runStageSevenCommand(command) {
  if (!command) return;
  addLine(`$ ${command}`);
  game.attempts++;
  game.totalActions++;
  document.getElementById("rival-score").textContent = game.rivalScore;

  scheduleTimeout(() => {
    if (command === game.commandSequence[game.commandIndex]) {
      addLine(`Executed: ${command}`, "success");
      game.commandIndex++;
      award(35);
      if (game.commandIndex === game.commandSequence.length) {
        addLine("Server control unlocked.", "success");
        award(125);
        nextButton("Enter High Security Layer", 8);
      }
    } else if (command === "help" || command === "status") {
      addLine(`Next required command: ${game.commandSequence[game.commandIndex]}`, "ai");
    } else if (command === "disconnect") {
      game.ending = "failure";
      renderStage(10);
    } else {
      game.failedAttempts++;
      addLine("Command rejected by server monitor.", "warning");
      flashWarning();
    }
  }, 280);
}

function renderMultiSecurity() {
  addLine("HIGH SECURITY WARNING.", "warning");
  addLine("Layer stack: password check + cipher decode + firewall bypass + command execution.");
  addLine("Connect to main server by satisfying every layer.");

  setControls(`
    <div class="form-row">
      <div>
        <label for="multi-pass">Password</label>
        <input id="multi-pass" type="text" placeholder="A + number, length 5">
      </div>
      <div>
        <label for="multi-cipher">${game.cipher.type} cipher: ${game.cipher.encrypted}</label>
        <input id="multi-cipher" type="text" placeholder="decoded word">
      </div>
      <div>
        <label for="multi-command">Command</label>
        <input id="multi-command" type="text" placeholder="access">
      </div>
      <button class="primary-button" id="multi-submit" type="button">Bypass Layers</button>
    </div>
  `);

  document.getElementById("multi-submit").addEventListener("click", () => {
    const password = document.getElementById("multi-pass").value.trim();
    const cipher = document.getElementById("multi-cipher").value.trim().toUpperCase();
    const command = document.getElementById("multi-command").value.trim().toLowerCase();
    game.attempts++;
    game.totalActions++;

    if (isValidFirewallPassword(password) && cipher === game.cipher.answer && command === "access") {
      addLine("All security layers bypassed. Main server connected.", "success");
      award(180);
      nextButton("Begin Final Hack", 9);
    } else {
      game.failedAttempts++;
      addLine("Layer mismatch. Security pressure increasing.", "warning");
      flashWarning();
    }
  });
}

function renderFinalHack() {
  addLine("Root access challenge initialized.", "warning");
  addLine("Final command: root unlock");
  addLine(`Final firewall token: ${game.finalToken}`);
  addLine("Final cipher: 8-5-12-12-15");

  setControls(`
    <div class="progress"><span id="root-progress" style="--value: 0%;"></span></div>
    <div class="form-row">
      <div>
        <label for="final-command">Root command</label>
        <input id="final-command" type="text">
      </div>
      <div>
        <label for="final-token">Firewall token</label>
        <input id="final-token" type="text">
      </div>
      <div>
        <label for="final-cipher">Number cipher decode</label>
        <input id="final-cipher" type="text">
      </div>
      <button class="primary-button" id="final-submit" type="button">Execute Final Hack</button>
    </div>
  `);

  document.getElementById("final-submit").addEventListener("click", () => {
    const command = document.getElementById("final-command").value.trim().toLowerCase();
    const token = document.getElementById("final-token").value.trim();
    const cipher = document.getElementById("final-cipher").value.trim().toUpperCase();
    game.attempts++;
    game.totalActions++;
    animateProgress("root-progress", 100);
    addLine("Executing final payload...");
    addLine("Writing trace mask...");
    addLine("Breaking final firewall...");

    scheduleTimeout(() => {
      if (command === "root unlock" && token === game.finalToken && cipher === "HELLO") {
        game.finalSuccess = true;
        game.ending = chooseEnding();
        addLine("ROOT ACCESS GRANTED.", "success");
        unlockAchievement("root");
        award(250);
        nextButton("View Results", 10);
      } else {
        game.failedAttempts++;
        addLine("Final hack failed. Intrusion monitor is awake.", "warning");
        flashWarning();
        if (game.failedAttempts >= 8 || game.mode === "Hardcore") {
          game.finalSuccess = false;
          game.ending = "detected";
          renderStage(10);
        }
      }
    }, 900);
  });
}

function renderResults() {
  clearTimers();
  const elapsed = Math.max(1, Math.floor((Date.now() - game.startTime) / 1000));
  const accuracy = game.totalActions === 0 ? 100 : Math.round((game.correctActions / game.totalActions) * 100);
  const efficiency = Math.max(0, Math.round((accuracy * 0.6) + (Math.max(0, 10 - game.failedAttempts) * 4)));
  const speedRating = elapsed <= 90 ? "Blazing" : elapsed <= 180 ? "Fast" : elapsed <= 300 ? "Stable" : "Slow";
  const timeBonus = game.finalSuccess ? Math.max(0, game.countdown) : 0;
  const stealthBonus = game.finalSuccess && game.failedAttempts <= 2 ? 120 : 0;
  const hintPenalty = game.hints * 15;
  const finalScore = game.finalSuccess ? game.score + timeBonus + stealthBonus - hintPenalty : Math.max(0, game.score - 100 - hintPenalty);
  const currentProfile = getProfile(game.user);
  const rank = getRank(finalScore, accuracy, game.hints, currentProfile.xp);
  const endingText = getEndingText(game.ending);

  game.score = Math.max(0, finalScore);
  updateHud();
  addLine(endingText, game.finalSuccess ? "success" : "warning");
  addLine(`Mission status: ${game.finalSuccess ? "SUCCESS" : "FAILED"}`);
  addLine(`Rank reveal: ${rank}`, "success");

  if (game.finalSuccess && game.failedAttempts <= 2) unlockAchievement("silent");
  if (rank === "Elite" || rank === "Master" || rank === "Ghost Hacker" || rank === "Cyber Phantom" || rank === "Darknet Legend") unlockAchievement("elite");
  if (rank === "Darknet Legend") unlockAchievement("legend");
  if (game.finalSuccess && game.hints === 0) unlockAchievement("ghost");

  const profile = updateProfile(profileData => {
    profileData.rank = rank;
    profileData.lastScore = game.score;
    profileData.bestScore = Math.max(profileData.bestScore, game.score);
    profileData.credits += Math.max(0, Math.round(game.score * 0.04));
    profileData.xp += game.finalSuccess ? Math.round(game.score * 0.12) : 25;
    if (game.finalSuccess) profileData.missionsCompleted++;
    if (game.daily && game.finalSuccess) profileData.dailyChallengesCompleted++;
    profileData.stage = game.stage;
    profileData.attempts = game.attempts;
    profileData.accuracy = accuracy;
    profileData.fastestTime = profileData.fastestTime === null ? elapsed : Math.min(profileData.fastestTime, elapsed);
    profileData.performance.totalRuns++;
    if (game.finalSuccess) profileData.performance.totalWins++;
    profileData.performance.bestAccuracy = Math.max(profileData.performance.bestAccuracy, accuracy);
    profileData.performance.bestCombo = Math.max(profileData.performance.bestCombo, game.bestCombo || game.combo);
    if (game.finalSuccess) {
      profileData.performance.fastestWin = profileData.performance.fastestWin === null
        ? elapsed
        : Math.min(profileData.performance.fastestWin, elapsed);
    }
    profileData.achievements = Array.from(new Set([...profileData.achievements, ...game.sessionAchievements]));
    tools.forEach(tool => {
      if ((game.score >= tool.unlock || profileData.level >= tool.unlockLevel) && !profileData.tools.includes(tool.id) && tool.cost === 0) {
        profileData.tools.push(tool.id);
        profileData.toolLevels[tool.id] = 1;
      }
    });
    profileData.matchHistory.unshift({
      mode: game.mode,
      score: game.score,
      rank,
      result: game.finalSuccess ? "win" : "loss",
      accuracy,
      attempts: game.attempts,
      time: elapsed,
      xp: game.xpEarned,
      credits: game.creditsEarned
    });
    profileData.matchHistory = profileData.matchHistory.slice(0, 5);
  });

  setControls(`
    <div class="result-grid">
      <div class="result-card"><strong>Final Score</strong>${game.score}</div>
      <div class="result-card"><strong>Rank</strong>${rank}</div>
      <div class="result-card"><strong>XP Earned</strong>${game.xpEarned}</div>
      <div class="result-card"><strong>Credits Earned</strong>${game.creditsEarned}</div>
      <div class="result-card"><strong>Ending</strong>${endingText}</div>
      <div class="result-card"><strong>Attempts</strong>${game.attempts}</div>
      <div class="result-card"><strong>Hints</strong>${game.hints}</div>
      <div class="result-card"><strong>Accuracy</strong>${accuracy}%</div>
      <div class="result-card"><strong>Efficiency</strong>${efficiency}%</div>
      <div class="result-card"><strong>Speed Rating</strong>${speedRating}</div>
      <div class="result-card"><strong>Time</strong>${formatTime(elapsed)}</div>
      <div class="result-card"><strong>Rival Score</strong>${game.rivalScore}</div>
    </div>
    <div class="control-grid" style="margin-top: 16px;">
      <button class="primary-button" id="play-again" type="button">Play Again</button>
      <button class="ghost-button" id="endless" type="button">Endless Operation</button>
      <button class="ghost-button" id="credits" type="button">Credits</button>
      <button class="ghost-button" id="exit" type="button">Exit To Lobby</button>
    </div>
  `);

  document.getElementById("play-again").addEventListener("click", () => startGame(game.mode));
  document.getElementById("endless").addEventListener("click", () => startGame("Endless"));
  document.getElementById("credits").addEventListener("click", () => {
    addLine("Credits: Built with HTML, CSS, JavaScript UI, and modular C++ game logic concepts.");
  });
  document.getElementById("exit").addEventListener("click", () => {
    returnToMainMenu(false);
  });
}

function chooseEnding() {
  if (game.score >= 900 && game.hints === 0 && game.failedAttempts === 0) return "secret";
  if (game.failedAttempts <= 2 && game.hints <= 1) return "stealth";
  return "success";
}

function getEndingText(ending) {
  const endings = {
    success: "You escaped detection",
    failure: "System lockdown activated",
    detected: "Intrusion detected. Trace completed.",
    stealth: "Stealth ending: you vanished without a trace.",
    secret: "Secret ending: Cyber Phantom protocol unlocked."
  };
  return endings[ending] || endings.failure;
}

function getRank(score, accuracy = 0, hints = 0, xp = 0) {
  if (score >= 1600 && accuracy >= 90 && xp >= 4500 && hints <= 1) return "Darknet Legend";
  if (score >= 1250 && accuracy >= 85 && hints === 0) return "Cyber Phantom";
  if (score >= 1050 && accuracy >= 80) return "Ghost Hacker";
  if (score >= 900) return "Master";
  if (score >= 700) return "Elite";
  if (score >= 450) return "Skilled";
  return "Rookie";
}

function xpRequiredForLevel(level) {
  return Math.round(100 + level * 45 + Math.pow(level, 1.35) * 18);
}

function getLevelFromXp(xp) {
  let level = 1;
  let remaining = Math.max(0, xp || 0);

  while (remaining >= xpRequiredForLevel(level) && level < 1000) {
    remaining -= xpRequiredForLevel(level);
    level++;
  }

  return level;
}

function getXpProgress(xp) {
  let level = 1;
  let remaining = Math.max(0, xp || 0);

  while (remaining >= xpRequiredForLevel(level) && level < 1000) {
    remaining -= xpRequiredForLevel(level);
    level++;
  }

  const required = xpRequiredForLevel(level);
  return {
    current: remaining,
    required,
    percent: Math.min(100, Math.round((remaining / required) * 100))
  };
}

function getRankProgress(profile) {
  const rankOrder = [
    { name: "Rookie", xp: 0 },
    { name: "Skilled", xp: 650 },
    { name: "Elite", xp: 1400 },
    { name: "Master", xp: 2400 },
    { name: "Ghost Hacker", xp: 3600 },
    { name: "Cyber Phantom", xp: 4800 },
    { name: "Darknet Legend", xp: 6500 }
  ];
  const currentIndex = Math.max(0, rankOrder.findIndex(rank => rank.name === profile.rank));
  const next = rankOrder[Math.min(currentIndex + 1, rankOrder.length - 1)];
  const current = rankOrder[currentIndex] || rankOrder[0];
  const span = Math.max(1, next.xp - current.xp);
  return {
    next: next.name,
    percent: next.name === current.name ? 100 : Math.max(0, Math.min(100, Math.round(((profile.xp - current.xp) / span) * 100)))
  };
}

function showRewardBurst(title, text = "") {
  const popup = document.createElement("div");
  popup.className = "achievement-popup reward-burst";
  popup.innerHTML = `<strong>${title}</strong><span>${text}</span>`;
  achievementStack.appendChild(popup);
  setTimeout(() => popup.remove(), 4200);
}

function aiSay(message) {
  if (game.stage >= 1 && game.stage < 10 && terminalOutput) {
    addLine(`AI ASSISTANT: ${message}`, "ai", true);
  }

  const popup = document.createElement("div");
  popup.className = "ai-hologram";
  popup.innerHTML = `<strong>AI Assistant</strong><span>${message}</span>`;
  achievementStack.appendChild(popup);
  setTimeout(() => popup.remove(), 3600);
}

function aiReact(type) {
  if (Math.random() > 0.18) return;
  const lines = {
    success: ["Good work, Agent.", "Clean execution.", "That route is stable.", "Firewall strength dropping."],
    warning: ["That was dangerously close.", "Firewall strength increasing.", "Use stealth mode if you have it.", "Trace monitor is waking up."]
  };
  aiSay(pick(lines[type] || lines.success));
}

function maybeRandomEvent(stage) {
  if (game.eventStages.has(stage) || game.mode === "Training" || Math.random() > 0.22) return;
  game.eventStages.add(stage);
  const event = pick(randomEvents);

  addLine(event.title, event.type === "risk" ? "warning" : "success", true);
  addLine(event.text, "ai", true);

  if (event.xp) grantXP(event.xp, event.title);
  if (event.credits) grantCredits(event.credits, "event cache");

  if (event.penalty) {
    const shielded = hasTool("shield");
    game.countdown = Math.max(20, game.countdown - (shielded ? Math.round(event.penalty / 2) : event.penalty));
    if (shielded) addLine("Firewall Shield absorbed part of the event impact.", "success");
    flashWarning();
  }
}

function toDateKey(date) {
  return date.toISOString().slice(0, 10);
}

function unlockAchievement(id) {
  const item = achievements[id];
  if (!item || game.sessionAchievements.has(item.name)) return;
  game.sessionAchievements.add(item.name);
  if (game.user) {
    updateProfile(profile => {
      if (!profile.achievements.includes(item.name)) profile.achievements.push(item.name);
    });
  }
  showAchievement(item);
}

function showAchievement(item) {
  const popup = document.createElement("div");
  popup.className = "achievement-popup";
  popup.innerHTML = `<strong>Achievement Unlocked</strong>${item.name}<br><span>${item.text}</span>`;
  achievementStack.appendChild(popup);
  setTimeout(() => popup.remove(), 4200);
}

function useHint(text) {
  let freeHint = false;
  const profile = getProfile(game.user);

  if (profile.bonusHints > 0 || hasTool("hintUnlocker")) {
    freeHint = true;
    updateProfile(item => {
      if (item.bonusHints > 0) item.bonusHints--;
    });
  }

  game.hints++;
  game.score = Math.max(0, game.score - (game.mode === "Training" || freeHint ? 0 : 10));
  addLine(text, "ai");
  showRewardBurst(freeHint ? "Bonus Hint Used" : "Hint Used", freeHint ? "No score penalty" : "-10 score");
  const hintCount = document.getElementById("hint-count");
  if (hintCount) hintCount.textContent = game.hints;
  updateHud();
}

function hasTool(id) {
  const profile = getProfile(game.user);
  return profile.tools.includes(id);
}

function getToolLevel(id) {
  const profile = getProfile(game.user);
  return profile.toolLevels[id] || (profile.tools.includes(id) ? 1 : 0);
}

function saveProgress() {
  if (!game.user) return;
  updateProfile(profile => {
    profile.stage = game.stage;
    profile.lastScore = game.score;
    profile.attempts = game.attempts;
  });
}

function getDailyChallenge() {
  const dateKey = new Date().toISOString().slice(0, 10);
  const seed = [...dateKey].reduce((total, char) => total + char.charCodeAt(0), 0);
  const objectives = ["Crack 3 firewalls", "Decode hidden cipher", "Complete mission under 60 seconds", "Stealth-only challenge"];
  return {
    name: ["Midnight Firewall", "Cipher Rain", "Ghost Relay", "Blackout Route"][seed % 4],
    target: missions[seed % missions.length].target,
    modifier: ["Noisy firewall", "Rotating cipher", "Short timer", "Extra open ports"][seed % 4],
    objective: objectives[seed % objectives.length],
    timer: `${8 + (seed % 7)}h remaining`,
    reward: 75 + (seed % 5) * 10,
    credits: 35 + (seed % 4) * 10
  };
}

function getLeaderboard(profile) {
  const fastest = profile.fastestTime === null ? "--:--" : formatTime(profile.fastestTime);
  return [
    { name: profile.codeName || profile.username, score: profile.bestScore, accuracy: profile.accuracy, attempts: profile.attempts, time: fastest },
    { name: "NullVector", score: 1180, accuracy: 94, attempts: 8, time: "02:14" },
    { name: "CipherSaint", score: 1035, accuracy: 91, attempts: 9, time: "02:42" },
    { name: "RootWarden", score: 920, accuracy: 88, attempts: 11, time: "03:05" },
    { name: "PortGhost", score: 760, accuracy: 82, attempts: 13, time: "03:40" }
  ].sort((a, b) => b.score - a.score);
}

function buildRivals(profile) {
  return [
    { name: "NullVector", rank: "Master", score: 1000 + Math.floor(Math.random() * 180) },
    { name: "CipherSaint", rank: "Elite", score: 820 + Math.floor(Math.random() * 160) },
    { name: profile.friends[0], rank: "Skilled", score: 600 + Math.floor(Math.random() * 170) }
  ];
}

function generatePassword() {
  const letters = "BCDEFGHJKLMNPQRSTUVWXYZ";
  return `A${Math.floor(Math.random() * 10)}${pick([...letters])}${pick([...letters]).toLowerCase()}${Math.floor(Math.random() * 10)}`;
}

function isValidFirewallPassword(password) {
  return password.length === 5 && password.startsWith("A") && /\d/.test(password);
}

function generatePorts() {
  const common = [21, 22, 25, 53, 80, 110, 443, 3306, 5432, 5900, 8080];
  const shuffled = common.sort(() => Math.random() - 0.5).slice(0, 6);
  const openIndex = Math.floor(Math.random() * shuffled.length);
  return shuffled.map((port, index) => {
    const open = index === openIndex || Math.random() > 0.58;
    return {
      port,
      open,
      state: open ? "OPEN" : Math.random() > 0.5 ? "CLOSED" : "FIREWALL"
    };
  });
}

function animateProgress(id, target) {
  const bar = document.getElementById(id);
  if (!bar) return;
  let value = 0;
  const interval = scheduleInterval(() => {
    value += 10;
    bar.style.setProperty("--value", `${Math.min(value, target)}%`);
    if (value >= target) clearInterval(interval);
  }, 80);
}

function flashWarning() {
  screenFlash.classList.remove("warning-flash");
  void screenFlash.offsetWidth;
  screenFlash.classList.add("warning-flash");
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function shuffleList(list) {
  const shuffled = [...list];
  for (let index = shuffled.length - 1; index > 0; index--) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function formatTime(seconds) {
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function clearTimers() {
  clearInterval(timerId);
  clearInterval(countdownId);
  runtimeIntervals.delete(timerId);
  runtimeIntervals.delete(countdownId);
  timerId = null;
  countdownId = null;
}

function initMatrix() {
  const context = matrixCanvas.getContext("2d");
  const glyphs = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ#$%";
  let columns = [];

  function resize() {
    matrixCanvas.width = window.innerWidth;
    matrixCanvas.height = window.innerHeight;
    columns = Array(Math.ceil(matrixCanvas.width / 18)).fill(0);
  }

  function draw() {
    context.fillStyle = "rgba(2, 4, 3, 0.18)";
    context.fillRect(0, 0, matrixCanvas.width, matrixCanvas.height);
    context.fillStyle = "#00ff7f";
    context.font = "14px Consolas, monospace";
    columns.forEach((y, index) => {
      const text = glyphs[Math.floor(Math.random() * glyphs.length)];
      context.fillText(text, index * 18, y);
      columns[index] = y > matrixCanvas.height + Math.random() * 10000 ? 0 : y + 18;
    });
    requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener("resize", resize);
  draw();
}

initMatrix();
