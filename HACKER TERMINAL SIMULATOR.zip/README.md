# Hacker Terminal Simulator

A cyberpunk-style multi-stage hacker terminal game with:

- C++ game logic in `NEW.CPP`
- Web UI in `index.html`, `style.css`, and `script.js`
- Login/signup using browser `localStorage`
- A dedicated How To Play guide and interactive training mode
- 10 strict stages with score, attempts, hints, ports, commands, ciphers, timer pressure, and final rank
- Profile saving for score, stage, attempts, rank, achievements, tools, match history, and streaks
- Simulated multiplayer, daily challenges, leaderboard, achievements, randomized puzzles, and multiple endings

## Features

- Cyberpunk terminal UI with Matrix background, CRT scanlines, glitch warnings, progress bars, animated ports, and achievement popups
- Game modes: Story, Endless, Hardcore, Challenge, Speedrun, and Training
- Randomized missions, passwords, ciphers, ports, final tokens, and simulated rivals
- Password Firewall includes manual cracking and an educational simulated brute force attack with animated attempts, cracking speed, progress, and lower scoring
- Inventory tools: decryptor, port scanner, firewall bypass, stealth mode, and password cracker
- Ranks: Rookie, Skilled, Elite, Master, Ghost Hacker, Cyber Phantom, and Darknet Legend
- Endings: success, failure, detected, stealth, and secret
- XP progression with levels, level-up rewards, credits, combo bonuses, rank progress, and animated reward bursts
- Daily login streaks with XP, credits, bonus hints, and streak popups
- Black Market Shop with buy/sell, tool upgrades, rarity, locked items, and gameplay effects
- Random risk/reward events and AI assistant reactions during missions
- Performance analytics dashboard with win rate, best accuracy, average score, fastest win, best combo, grade, and recommended next goal
- Optional Puzzle Lab with Memory Hack, Guess the Number, Reverse Cipher, Binary Translation, Morse Code, Logic Gate, Pattern Prediction, and Speed Typing challenges

## Run The Web Version

Use either option:

1. Open this folder in VS Code and run `index.html` with Live Server.
2. Or serve the folder with Node:

```bash
node server.js
```

Then open:

```text
http://localhost:3000
```

## Run The C++ Engine

Compile:

```bash
g++ NEW.CPP -o hacker-terminal
```

Run:

```bash
./hacker-terminal
```

On Windows PowerShell:

```powershell
.\hacker-terminal.exe
```

## Notes

The browser cannot directly execute C++ without a backend or WebAssembly setup, so the web UI mirrors the C++ engine logic for easy localhost play. `NEW.CPP` contains the main terminal game engine using functions, strings, arrays/vectors, conditionals, loops, switch case, random generation, stack-based reverse decoding, structures, tools, achievements, modes, and rank logic.
